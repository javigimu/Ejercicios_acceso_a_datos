/**
 * 
 */
/**
 * @author Javi
 *
 */
module ejercicio0123 {
	requires java.xml;
}