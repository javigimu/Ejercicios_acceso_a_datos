package ejercicio0123;

/**
 * Muestra las asignaturas del segundo fichero asignaturas.xml
 * @author Javi
 *
 */

public class Ejercicio0123 {

	public static void main(String[] args) {
		ReadXml ficheroXml = new ReadXml();
		ficheroXml.procesarXml();

	}

}
