package com.javier.ejercicio0130;

import java.util.Comparator;
import java.util.List;
import java.util.Scanner;
import java.util.stream.Collectors;

import com.javier.entidades.Coche;
import com.javier.utilidades.utilidades;

/**
 * leer el fichero coches.json usando la API Modelos, la API Streaming
 * y la API GSON
 * se muestra el modelo de los coches de una marca pedida al usuario
 * @author Javi
 *
 */
public class App 
{
    public static void main( String[] args )
    {
    	Scanner sc = new Scanner(System.in);
    	boolean salir = false;
    	String opcion;
    	
    	do {    		
    		mostrarMenu();
    		opcion = recogerOpcion(sc);
    		switch (opcion) {
    			case "1": APIModelos(sc); break;
    			case "2": APIStreaming(sc); break;
    			case "3": APIGSON(sc); break;
    			case "s": salir = salir(); break;
				default: System.out.println("Opcion incorrecta"); break;
    		}    		
    	}while (!salir);    	
        
    }
    
    public static String pedirMarca(Scanner sc) {
    	System.out.print("Introduce la marca: ");
    	return sc.nextLine();
    }
    
    public static boolean salir() {
    	System.out.println("Hasta la proxima");
    	return true;
    }
    
    public static String recogerOpcion(Scanner sc) {
    	System.out.print("Introduce una opcion: ");
    	return sc.nextLine().toLowerCase();
    }
    
    /**
     * Obtengo los nombres de los coches cuya marca sea introducida por el cliente 
     * ordenados por cilindrada descendente
     * @param sc
     */
    public static void APIModelos(Scanner sc) {
    	String marca = pedirMarca(sc);
    	List<Coche> listaCoches = utilidades.leerJsonDesdeFichero("coches.json");
    	List<String> modelos = listaCoches.stream()
        	.filter(c -> c.getMarca().equalsIgnoreCase(marca))
        	.sorted((c1, c2) -> Integer.compare(c2.getCilindrada(), 
        			c1.getCilindrada()))
        	.map(Coche::getModelo)
			.collect(Collectors.toList());
    	
    	if (modelos.isEmpty())
    		System.out.println("No se han encontrado coincidencias");
    	else
    		modelos.forEach(System.out::println);
    }
    
    public static void APIStreaming(Scanner sc) {
    	// TO DO
    }
    
    /**
     * Obtengo los nombres de los coches cuya marca sea introducida por el cliente 
     * ordenados por cilindrada descendente
     * @param sc
     */
    public static void APIGSON(Scanner sc) {
    	String marca = pedirMarca(sc);
    	List<Coche> listaCoches = utilidades.leerFicheroConGson("coches.json",
    			Coche[].class);
    	listaCoches.stream()
    		.filter(c -> c.getMarca().equalsIgnoreCase(marca))
    		.sorted((c1, c2) -> Integer.compare(c2.getCilindrada(), 
    				c1.getCilindrada()))
    		.map(Coche::getModelo)
    		.forEach(System.out::println);
    }
    
    public static void mostrarMenu() {
    	System.out.println();
    	System.out.println("1. API Modelos");
    	System.out.println("2. API Streaming");
    	System.out.println("3. API GSON");
    	System.out.println("s. Salir");
    	System.out.println();
    }
}
