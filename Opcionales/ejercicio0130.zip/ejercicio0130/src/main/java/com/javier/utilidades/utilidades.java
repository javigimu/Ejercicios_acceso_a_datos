package com.javier.utilidades;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import com.google.gson.Gson;
import com.javier.entidades.Coche;

public class utilidades {
	public static List<Coche> leerJsonDesdeFichero(String cadenaCompleta) {
		
		List<Coche> listaCoches = new ArrayList<>();
		Object obj;
		try {
			// parseado el fichero "coches.json"
			obj = new JSONParser().parse(new FileReader(cadenaCompleta));
			// casteando obj a JSONObject
			JSONObject jo = (JSONObject) obj;
			// cogiendo la marca, el modelo y la cilindrada
			// muestro lo que he leido del fichero json
			//System.out.println("JSON leido: " + jo);
			
			JSONObject joCoches = (JSONObject) jo.get("coches");
			//System.out.println("JObject coches: " + joCoches);
			
			JSONArray coches = (JSONArray) joCoches.get("coche");			
			// muestro el array de coches
			//System.out.println("");
			//coches.stream().forEach(System.out::println);
			
			for (int i = 0; i < coches.size(); i++) {
				JSONObject coche = (JSONObject) coches.get(i);
				listaCoches.add(new Coche(
						coche.get("marca").toString(), 
						coche.get("modelo").toString(), 
						Integer.parseInt(coche.get("cilindrada").toString())));
			}

			//listaCoches.stream().forEach(System.out::println);

		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return listaCoches;
	}
	
	/**
	 * Parsea el fichero coches.json indicado en cadenaCompleta para obtener
	 * los campos que realmente interesan y devuelve un jsonString
	 * @param cadenaCompleta
	 * @return
	 */
	public static String parsearFicheroJson(String cadenaCompleta) {
		try {
			// parseado el fichero "coches.json"
			Object obj = new JSONParser().parse(new FileReader(cadenaCompleta));
			// casteando obj a JSONObject
			JSONObject jo = (JSONObject) obj;
			
			JSONObject joCoches = (JSONObject) jo.get("coches");			
			JSONArray coches = (JSONArray) joCoches.get("coche");
			
			return coches.toString();
			
		}catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return "";
	}
	
	/**
	 * Con este método se obtiene una lista de tipo genérico con la extracción
	 * de datos del fichero json con formato correcto en cadenaCompleta	
	 * @param <T>
	 * @param cadenaCompleta
	 * @param clase
	 * @return
	 */
	public static <T> List<T> leerFicheroConGson(String cadenaCompleta,
			Class<T[]> clase) {
        return Arrays.asList(new Gson().fromJson(
        		parsearFicheroJson(cadenaCompleta),clase));
	}

	/**
	 * Método para leer un fichero json en formato correcto y devuelve
	 * un String con todas las líneas
	 * @param rutaCompleta
	 * @return
	 */
	public static String leerFichero11(String rutaCompleta){
		try {
			return Files.readString(Paths.get(rutaCompleta),StandardCharsets.UTF_8);
		} catch (IOException e) {
			e.printStackTrace();
		}
		return null;
	}
}
