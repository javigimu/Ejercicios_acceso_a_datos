package com.javier.entidades;

import java.io.Serializable;

public class Usuario implements Serializable{
	
	private long userId;
	private long id;
	private String title;
	private boolean completed;
	/**
	 * @param userId
	 * @param id
	 * @param title
	 * @param completed
	 */
	public Usuario(long userId, long id, String title, boolean completed) {
		super();
		this.userId = userId;
		this.id = id;
		this.title = title;
		this.completed = completed;
	}
	public long getUserId() {
		return userId;
	}
	public long getId() {
		return id;
	}
	public String getTitle() {
		return title;
	}
	public boolean isCompleted() {
		return completed;
	}
	
	@Override
	public String toString()
	{
		return userId + ", " + id + ", " + title + ", " 
	+ (completed? "completado" : "incompleto");
	}

}