package com.javier.utilidades;

import java.util.Arrays;
import java.util.List;

import com.google.gson.Gson;

public class JsonUtils {

	/**
	 * Metódo genérico que dada una url con un json donde se encuentra un array de objetos
	 * devuelve una lista de ese tipo de objetos que contiene todos los objetos introducidos.
	 * Ejemplo de llamada: JsonUtils.devolverGsonGenerico("https://jsonplaceholder.typicode.com/todos",Tarea[].class)
	 * @param <T> Nombre de la clase
	 * @param url
	 * @param clase Array de elementos del tipo de la clase
	 * @return
	 */
	public static <T> List<T> devolverArrayGsonGenerico(String url,Class<T[]> clase) {
        return Arrays.asList(new Gson().fromJson(InternetUtils.readUrl(url),clase));
	}
}
