package com.javier.ejercicio0131;

import java.util.List;
import java.util.function.Predicate;
import java.util.stream.Collectors;

import com.javier.entidades.Usuario;
import com.javier.utilidades.JsonUtils;
import com.javier.utilidades.SerializationUtils;

/**
 * Dada una url que ofrece datos en formato Json
 * https://jsonplaceholder.typicode.com/todos para esta ejemplo
 * Devuelve el contenido en una lista de tipo Usuario
 * y muestro los que tengan un userId par y el campo completed a true
 * Después se serializa al fichero usuarios.dat
 */
public class App 
{
    public static void main( String[] args )
    {        
    	final String FICHERO_SERIALIZACION = "usuariosParIncompletos.dat";
    	Predicate<Usuario> pCompleted = u -> u.isCompleted() == false;
    	Predicate<Usuario> pUserIdEsPar = u -> u.getUserId() % 2 == 0;
    	
        List<Usuario> listaUsuarios = JsonUtils.devolverArrayGsonGenerico(
        		"https://jsonplaceholder.typicode.com/todos",
        		Usuario[].class);
        
        List<Usuario> usuariosParIncompletos = listaUsuarios.stream()
    	.filter(pUserIdEsPar.and(pCompleted))
		.collect(Collectors.toList());     
        
        usuariosParIncompletos.forEach(System.out::println);
        
        SerializationUtils.serializarListaObjetos(
        		SerializationUtils.obtenerDirectorioTrabajoActual(), 
        		FICHERO_SERIALIZACION, usuariosParIncompletos);
        System.out.println();
        System.out.println("Datos serializados correctamente en "
        		+ "usuariosParIncompletos.dat");
        
        List<Usuario> usuariosDeserializados = 
        		SerializationUtils.desSerializarListaObjetos(
        				SerializationUtils.obtenerDirectorioTrabajoActual(), 
        				FICHERO_SERIALIZACION);
        System.out.println();
        System.out.println("Datos deserializados");
        usuariosDeserializados.forEach(System.out::println);
    }
}
