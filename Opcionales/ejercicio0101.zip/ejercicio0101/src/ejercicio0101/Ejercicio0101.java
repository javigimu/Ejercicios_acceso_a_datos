package ejercicio0101;

/** 
 * 
 * @author Javi
 * Saludo
 *
 */

public class Ejercicio0101 {

	public static void main(String[] args) {
		System.out.println("Hola");
	}

}
