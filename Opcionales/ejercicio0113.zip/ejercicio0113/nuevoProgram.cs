e("Introduce una letra");
            var letra = Console.ReadKey(true);
            if (letra.KeyChar >= 'A' && letra.KeyChar <= 'Z')
            {
                Console.WriteLine("La letra es mayúscula");
            }
            else
            {
                Console.WriteLine("La letra no es mayúscula");
            }
        }
        static void Main(string[] args)
        {
            Ejercicio1();
            Ejercicio2();
        }
    }
}
{
            Console.WriteLine("Introduce una letra");
            var letra = Console.ReadKey(true);
            if (letra.KeyChar >= 'A' && letra.KeyChar <= 'Z')
            {
                Console.WriteLine("La letra es mayúscula");
            }
            else
            {
                Console.WriteLine("La letra no es mayúscula");
            }
        }
        static void Main(string[] args)
        {
            Ejercicio1();
            Ejercicio2();
        }
    }
}
{
            Console.WriteLin