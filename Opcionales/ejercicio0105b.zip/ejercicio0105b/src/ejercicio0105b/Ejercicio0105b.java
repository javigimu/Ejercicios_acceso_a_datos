package ejercicio0105b;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.Scanner;


/**
 * muestra un fichero de log y si no existe se lo pide al usuario
 * @author Javi
 *
 */
public class Ejercicio0105b {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		String fichero = "log.txt";
		
		if (!(new File(fichero).exists())) {			
			System.out.println("El fichero no existe");
			System.out.print("Introduce el nombre del fichero de logs: ");
			fichero = sc.nextLine();
		}
		if (new File(fichero).exists()) {
			try (BufferedReader br = new BufferedReader(new FileReader(
					fichero))){
				String linea = null;
				
				while ((linea = br.readLine()) != null) {
					System.out.println(linea);
				}				
				
			}catch (IOException ioe) {
				ioe.printStackTrace();
			}catch (Exception e) {
				e.printStackTrace();
			}		
		}else {
			System.out.println("El fichero no existe");
		}
	}
}
