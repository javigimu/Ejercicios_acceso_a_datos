package ejercicio0105;

import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;

/**
 * En cada ejecución añadirá al log que contendrá la fecha 
 * (en formato 19-09-2019), la hora (17:02:09) y el texto introducción 
 * por el usuario
 * @author Javi
 *
 */

public class Ejercicio0105 {

	public static void main(String[] args) {
		DateTimeFormatter formatFecha = 
				DateTimeFormatter.ofPattern("dd-MM-yyyy");
		DateTimeFormatter formatHora =
				DateTimeFormatter.ofPattern("HH:mm:ss");
		
		LocalDate fecha = LocalDate.now();
		LocalTime hora = LocalTime.now();
		String textoLog;
		Scanner sc = new Scanner(System.in);
		
		System.out.print("Introduce el texto del log: ");
		textoLog = sc.nextLine();
		
		try (PrintWriter pw = new PrintWriter(new BufferedWriter(
				new FileWriter("log.txt", true)))) {			
			
			pw.println(formatFecha.format(fecha) + " " +
			formatHora.format(hora) + " " + textoLog);			
		}catch (FileNotFoundException fne) {
			fne.printStackTrace();
		}catch (IOException ioe) {
			ioe.printStackTrace();
		}catch (Exception e) {
			e.printStackTrace();
		}
	}
}
