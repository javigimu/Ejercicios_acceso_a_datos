package com.javier.ejercicio0207;

import org.postgresql.util.PSQLException;

import com.javier.ejercicio0207.utilidades.JdbcUtils;

/**
 * actualiza la base de datos "dia02", añadiendo dos "proveedores" de ejemplo. 
 * se muestran los registros afectados por consola.
 *
 */
public class App 
{
	final static String USER ="postgres";
	final static String PASSWORD ="postgres";
	final static String URI ="jdbc:postgresql://localhost:5432/dia02";
	
    public static void main( String[] args ) throws PSQLException
    {
        String sql = "insert into proveedores values(?, ?);";
        
        JdbcUtils.conexion(URI, USER, PASSWORD);
		int resultado = JdbcUtils.preparedStatementInsertUpdateDelete(sql, "amz", "amazon");
		resultado += JdbcUtils.preparedStatementInsertUpdateDelete(sql, "msi", "msi solutions");
		JdbcUtils.desconexion();
		
		// al insertar un valor duplicado de la clave primaria, salta una PSQLEXception
		// indicando que la llave ya existe
		
		if (resultado > 0)
			System.out.println("inserciones realizadas correctamente");
		else
			System.err.println("No se han podido realizar las inserciones");
    }
}
