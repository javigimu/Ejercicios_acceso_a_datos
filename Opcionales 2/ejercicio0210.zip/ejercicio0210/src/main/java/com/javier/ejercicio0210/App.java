package com.javier.ejercicio0210;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.Scanner;

import com.javier.ejercicio0210.utilidades.DateUtils;
import com.javier.ejercicio0210.utilidades.JdbcUtils;
import com.javier.ejercicio0210.utilidades.NumberUtils;

/**
 * cursos (id, título, fechaIni) y usuarios que asisten (id, nombre). 
 * En cada curso puede haber múltiples usuarios, y supondremos que cada usuario sólo puede 
 * participar en un curso. 
 * Permitie añadir cursos, añadir participantes a un curso 
 * y ver todos los datos de un curso (incluyendo lista de participantes).
 *
 */
public class App 
{
	final static String USER ="postgres";
	final static String PASSWORD ="postgres";
	final static String URI ="jdbc:postgresql://localhost:5432/dia03";
	
    public static void main( String[] args )
    {    	
        String opcion;
        
        do {
        	mostrarMenu();
        	opcion = pedirDato("opcion");      		
			lanzarOpcion(opcion);          	      	
        }while (!opcion.equals("4"));    	
    }
    
    private static void mostrarMenu() {
    	System.out.println("1-Anyadir curso");
    	System.out.println("2-Anyadir participante");
    	System.out.println("3-Listar datos curso");
    	System.out.println("4-Salir");
    }
    
    private static void lanzarOpcion(String opcion){
    	switch(opcion) {
    		case "1": anyadirCurso(); break;
    		case "2": anyadirUsuario(); break;
    		case "3": listarCursos(); break;
    		case "4": System.out.println("Hasta la proxima"); break;
			default: System.out.println("Opcion incorrecta"); break; 
    	}
    }
    
    private static void anyadirCurso() {    	
    	
    	String titulo = pedirDatoNoVacio("titulo");
    	String fecha = pedirDato("fecha de inicio");
    	LocalDate fechaIni = null;
    	if (!DateUtils.checkDate(fecha)) {
    		System.out.println("Formato de fecha incorrecto (yyyy-MM-dd)");
    	} else {
    		fechaIni = DateUtils.formatDate(fecha);
    	}
    		
    	String sql = "insert into cursos(titulo, fechaIni) values(?, ?);";
    	try {
    		JdbcUtils.conexion(URI, USER, PASSWORD);
    		
	    	int resultado = JdbcUtils.preparedStatementInsertUpdateDelete(sql, titulo, fechaIni);
	    	if (resultado > 0)
	    		System.out.println("Insercion correcta");
	    	else
	    		System.out.println("Error al insertar registro");  
    	}catch (SQLException e) {
    		e.printStackTrace();
    	} finally {    	
    		JdbcUtils.desconexion();
    	}
    }
    
    private static void anyadirUsuario() {
    	String nombre = pedirDatoNoVacio("nombre");
    	String curso = pedirDato("id del curso");
    	int id_curso = -1;
    	
    	if (NumberUtils.isNumeric(curso))
    		id_curso = Integer.parseInt(curso);
    	else
    		System.out.println("El curso es incorrecto");
    	
    	String sqlId_curso = "select * from cursos where id=" + id_curso;
    	String sql = "insert into usuarios(nombre, id_curso) values(?, ?);";
    	try {    	
    		JdbcUtils.conexion(URI, USER, PASSWORD);
    		ResultSet rs = JdbcUtils.devolverResultSet(sqlId_curso);
    		if (rs.next()) {
    			JdbcUtils.preparedStatementInsertUpdateDelete(sql, nombre, id_curso);
    		} else {
    			System.out.println("El id del curso no existe");
    			JdbcUtils.preparedStatementInsertUpdateDelete(sql, nombre, null);
    		}    		
    		System.out.println("Usuario anyadido correctamente");
    		
    	}catch (SQLException e) {
    		e.printStackTrace();
    	}finally {
    		JdbcUtils.desconexion();
    	}    	
    }
    
    private static void listarCursos() {
    	String sql = "select * from cursos";
    	JdbcUtils.conexion(URI, USER, PASSWORD);    	
    	try {
    		ResultSet rs = JdbcUtils.devolverResultSet(sql);
    		// muestra todos los cursos
	    	while (rs.next()) {
	    		System.out.println(rs.getInt("id") + ". " + rs.getString("titulo"));
	    	}
    	
	    	String id_curso = pedirDato("numero del curso");
	    	
	    	sql = "select * from cursos where id=" + id_curso;
	    	rs = JdbcUtils.devolverResultSet(sql);
	    	int resultados = 0;
	    	if (rs.next()) {
	    		resultados++;
	    		// muestra el curso seleccionado
	    		System.out.println(rs.getInt(1) + ". " + rs.getString(2) + ", " +
	    				rs.getString(3));
	    	}	  
	    	if (resultados == 0) {
    			System.out.println("No existe el curso introducido");
	    	} else {	    	
	    	
		    	sql = "select * from cursos c inner join usuarios u " +
	    			"on c.id=u.id_curso and c.id=" + id_curso + ";";
		    	
	    		rs = JdbcUtils.devolverResultSet(sql);
	    		resultados = 0;
	    		while (rs.next()) {
	    			resultados++;
	    			// muestra los participantes en el curso seleccionado
	    			System.out.println("\t" + rs.getString("nombre"));
	    		}
	    		if (resultados == 0)
	    			System.out.println("\tNo se han encontrado participantes");
	    	}
	    	
    	}catch(SQLException e) {
    		e.printStackTrace();
    	}finally {
        	JdbcUtils.desconexion();
    	}
    }
    
    private static String pedirDato(String dato) {
    	Scanner sc = new Scanner(System.in);
    	
    	System.out.print("Introduce " + dato + ": ");
    	return sc.nextLine();
    }
    
    private static String pedirDatoNoVacio(String dato) {
    	String datoNoVacio;
    	do {
    		datoNoVacio = pedirDato(dato);
    		if (datoNoVacio.isEmpty())
    			System.out.println(dato + " no puede estar vacío");
    	}while (datoNoVacio.isEmpty());
    	
    	return datoNoVacio;
    }
}
