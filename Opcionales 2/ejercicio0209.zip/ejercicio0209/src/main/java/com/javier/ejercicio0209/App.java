package com.javier.ejercicio0209;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

import com.javier.ejercicio0209.utilidades.JdbcUtils;

/**
 * conecta a la base de datos "dia01", y permita tanto añadir nuevos artículos como visualizar 
 * los que contengan un cierto texto introducido por el usuario.
 * muestra un menú con las opciones: 1-Buscar, 2-Añadir, 3-Modificar, 4-Salir
 * modificar: que pedirá al usuario el "id" de un artículo y, si éste existe, 
 * 				el nuevo valor para su nombre. Deberás usar la orden UPDATE de SQL
 *
 */
public class App 
{
	final static String USER ="postgres";
	final static String PASSWORD ="postgres";
	final static String URI ="jdbc:postgresql://localhost:5432/dia01";
	
    public static void main( String[] args )
    {
    	Scanner sc = new Scanner(System.in);
        String opcion;
        
        do {
        	mostrarMenu();
        	opcion = pedirDato("opcion", sc);      		
			lanzarOpcion(opcion, sc);  
        	      	
        }while (!opcion.equals("4"));
    }
    
    private static void mostrarMenu() {
    	System.out.println("1-Buscar");
    	System.out.println("2-Anyadir");
    	System.out.println("3-Modificar");
    	System.out.println("4-Salir");
    }
    
    /**
     * 1-Buscar, 2-Añadir, 3-Modificar, 4-Salir
     * @param opcion
     * @throws SQLException
     */
    private static void lanzarOpcion(String opcion, Scanner sc){
    	switch(opcion) {
    		case "1": buscarArticulo(sc); break;
    		case "2": anyadirArticulo(sc); break;
    		case "3": modificarArticulo(sc); break;
    		case "4": System.out.println("Hasta la proxima"); break;
			default: System.out.println("Opcion incorrecta"); break; 
    	}
    }
    
    private static void modificarArticulo(Scanner sc) {
    	int id = -1;
    	try {
    		id = Integer.parseInt(pedirDato("Id del articulo", sc));
    	}catch (NumberFormatException e) {
    		System.err.println("Id incorrecto");
    	}
    	
    	if (id > 0) {
    		JdbcUtils.conexion(URI, USER, PASSWORD);
    		// primero compruebo si el id existe
    		String sqlConsultaId = "select id from articulos where id=" + id;
    		ResultSet rs = JdbcUtils.preparedStatementSelect(sqlConsultaId);
    		boolean idExiste = false;
    		try {
				if (rs.next()) {
					idExiste = true;
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}    		
    		
    		// una vez sé que el id existe, pido el dato a modificar
    		if (idExiste) {    		
	    		String nuevoNombre = pedirDato("nuevo nombre", sc);   		
	    		
	    		String sql = "update articulos set nombre=? where id=?;";
	    		int resultado = 
	    				JdbcUtils.preparedStatementInsertUpdateDelete(sql, nuevoNombre, id);
	    		
	    		if (resultado > 0)
	    			System.out.println("Registro actualizado correctamente");
	    		else
	    			System.out.println("Error actualizando registro");
	    		
	    		JdbcUtils.desconexion();
    		}
    		else {
    			System.out.println("El id no existe");
    		}
    	}    	
    }
    
    private static void anyadirArticulo(Scanner sc) {
    	String nombre = pedirDato("nombre articulo", sc);
    	double precio = 1;
    	
    	try {
    		precio = Float.parseFloat(pedirDato("precio", sc));
    	}catch (NumberFormatException e)
    	{
    		System.err.println("Precio incorrecto, se deja el valor por defecto '1'");
    	}    	
    	
		String sqlMaxId = "select max(id) from articulos";
		JdbcUtils.conexion(URI, USER, PASSWORD);
	
    	ResultSet rs = JdbcUtils.devolverResultSet(sqlMaxId);
    	int id = 1;
    	try {
	    	while (rs.next()) {
	    		id = rs.getInt("max") + 1;
	    	}
    	}catch (SQLException e) {
    		System.err.println("Error al obtener el id maximo");
    	}
    	
    	String sql = "insert into articulos values(?, ?, ?);";    	
    	
    	int resultado = JdbcUtils.preparedStatementInsertUpdateDelete(sql, id, nombre, precio);
    	if (resultado > 0)
    		System.out.println("Insercion correcta");
    	else
    		System.out.println("Error al insertar registro");
	
    	JdbcUtils.desconexion();
    }
    
    private static void buscarArticulo(Scanner sc) {
    	String dato = pedirDato("texto a buscar", sc);
    	int cantidadRegistros = 0;
    	
    	try {
	    	String sql = "select * from articulos where nombre like '%" + dato + "%'";

	    	JdbcUtils.conexion(URI, USER, PASSWORD);
	    	
	    	ResultSet rs = JdbcUtils.preparedStatementSelect(sql);
	    	while (rs.next()) {
	    		cantidadRegistros++;
	    		System.out.println(rs.getInt("id") + " " + rs.getString("nombre") + " " + " -> " + rs.getFloat("precio"));	    		
	    	}
	    	if (cantidadRegistros == 0) {
	    		System.out.println("No se han encontrado coincidencias");
	    	}
	    	
	    	JdbcUtils.desconexion();
    	}catch (SQLException e) {
    		e.printStackTrace();
    	}
    }
    
    private static String pedirDato(String dato, Scanner sc) {
    	System.out.print("Introduce " + dato + ": ");
    	return sc.nextLine();
    }
}
