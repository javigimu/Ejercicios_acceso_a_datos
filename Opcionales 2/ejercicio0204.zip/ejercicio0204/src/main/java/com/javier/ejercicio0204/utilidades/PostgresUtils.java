package com.javier.ejercicio0204.utilidades;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class PostgresUtils {

	final static String USER ="postgres";
	final static String PASSWORD ="postgres";
	final static String URI ="jdbc:postgresql://localhost:5432/prueba";
	
	
	public static void conexion() {
		try(Connection con = DriverManager.getConnection(URI, USER, PASSWORD)){
			System.out.println("Conexión realizada correctamente");
		} catch (SQLException e) {
			e.printStackTrace();
			System.out.println("Fallo en la conexión");
		}
	}
	
	/**
	 * conecta a la base de datos especificada en uri y muestra todos los datos
	 * @param uri
	 */
	public static void conexion(String uri) {
		Statement statement = null;
		try(Connection con = DriverManager.getConnection(uri, USER, PASSWORD)){
			statement = con.createStatement();
			System.out.println("Conexión realizada correctamente");
			
			ResultSet rs = statement.executeQuery("SELECT * FROM articulos");
	    	while (rs.next()) {
	    		System.out.println(rs.getInt(1) + ", " + rs.getString("nombre")
	    		+ ", " + rs.getDouble("precio"));
	    	}
	    	rs.close();
		} catch (SQLException e) {
			e.printStackTrace();
			System.out.println("Fallo en la conexión");
		}
	}
	
}
