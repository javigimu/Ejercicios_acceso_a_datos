package com.javier.ejercicio0204;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.javier.ejercicio0204.utilidades.PostgresUtils;

/**
 * ejercicio de prueba de conexión con postgres
 *
 */
public class App 
{
    public static void main( String[] args ) 
    		throws ClassNotFoundException, SQLException {
    	
    	Class.forName("org.postgresql.Driver");
    	String uri = "jdbc:postgresql://localhost:5432/dia01";  
    	
    	PostgresUtils.conexion(uri);
    	
    }
}
