package com.javier.ejercicio0214.utilidades;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * metodos para operar con fechas
 * @author Javier Giménez Muñoz
 */
public class DateUtils {	
	
	
	/**
	 * formate la fecha en formato yyyy-MM-dd
	 * @param fecha
	 * @return
	 */
	public static LocalDate formatDate(String fecha){
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
		return LocalDate.parse(fecha, formatter);
	}
    
    /**
     * format time as "HH:mm:ss"
     * @param date
     * @return
     */
    public static String formatTime(LocalDateTime date) {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("HH:mm:ss");
        return formatter.format(date);
    }
    

    /**
     * checkea una cadena de texto para verificar si es una fecha correcta
     * @param txtDate en formato dd-MM-yyyy
     * @return
     */
    public static boolean checkDate(String txtDate)
    {
        boolean isCorrectDate = true;
        Pattern p = Pattern.compile("^\\d{4}-\\d{2}-\\d{2}$");
        Matcher m = p.matcher(txtDate);

        if (m.find())
        {
            String[] dateParts = txtDate.split("-");
            short year = Short.parseShort(dateParts[0]);            
            byte month = Byte.parseByte(dateParts[1]);
            byte day = Byte.parseByte(dateParts[2]);

            if (day > 0 && day <= 31 && month > 0 && month <= 12)
            {
                switch (month)
                {
                    case 2:
                        if (day > 29)
                            isCorrectDate = false;
                        break;
                    case 4:
                    case 6:
                    case 9:
                    case 11:
                        if (day == 31)
                            isCorrectDate = false;
                        break;
                    default:
                        if (year < 1000 && year > 3000)
                            isCorrectDate = false;
                        break;
                }
            }
            else
                isCorrectDate = false;
        }
        else
            isCorrectDate = false;

        return isCorrectDate;
    }
}
