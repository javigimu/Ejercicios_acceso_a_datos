package com.javier.ejercicio0205;

import java.sql.ResultSet;
import java.sql.SQLException;

import com.javier.ejercicio0205.utilidades.JdbcUtils;

/**
 * ejercicio con select
 *
 */
public class App 
{
	final static String USER ="postgres";
	final static String PASSWORD ="postgres";
	final static String URI ="jdbc:postgresql://localhost:5432/dia01";
	
    public static void main( String[] args )
    {
    	int cantidadRegistros = 0;
    	
    	try {
			//String sql = "Select * from articulos";
			String sql = "Select * from articulos where nombre like 'a%' or nombre like 'A%'";

			ResultSet rs = JdbcUtils.preparedStatementSelectCompleto(URI, USER, PASSWORD,sql);
			while(rs.next()) {
				cantidadRegistros++;
				System.out.println("ID: " + rs.getInt("id") + " Nombre: " + rs.getString("nombre") +
						" Precio: " + rs.getFloat("precio"));
			}
			if (cantidadRegistros == 0) {
				System.out.println("No se han encontrado coincidencias");
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    	
    }
}
