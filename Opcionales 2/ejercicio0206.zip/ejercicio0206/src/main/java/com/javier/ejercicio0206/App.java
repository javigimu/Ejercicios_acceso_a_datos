package com.javier.ejercicio0206;

import java.sql.SQLException;

import org.postgresql.util.PSQLException;

import com.javier.ejercicio0206.utilidades.JdbcUtils;

/**
 * amplía la base de datos "dia02", añadiendo una tabla "proveedores" 
 * (con estructura similar a la de "clientes") * 
 *
 */
public class App 
{
	final static String USER ="postgres";
	final static String PASSWORD ="postgres";
	final static String URI ="jdbc:postgresql://localhost:5432/dia02";
	
    public static void main(String[] args) throws PSQLException
    {
    	String sql = "create table proveedores("
				+ "id varchar(20) primary key,"
				+ "nombre varchar(30),"
				+ "fecha date default current_date"
				+ ");";

		JdbcUtils.conexion(URI, USER, PASSWORD);
		int resultado = JdbcUtils.preparedStatementInsertUpdateDelete(sql);			
		JdbcUtils.desconexion();
		
		// Al crear la tabla dos veces me da una excepción PSQLException indicando
		// que la relacion proveedores ya existe
    }
}
