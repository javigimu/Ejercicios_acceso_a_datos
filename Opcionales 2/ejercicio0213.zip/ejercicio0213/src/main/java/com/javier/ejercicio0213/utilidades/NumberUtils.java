package com.javier.ejercicio0213.utilidades;

public class NumberUtils {
	public static boolean isNumeric(String str) {
		  return str.matches("^\\d+$");  //match a positive number.
		}
}
