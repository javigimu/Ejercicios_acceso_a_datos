package com.javier.ejercicio0211;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.Scanner;

import com.javier.ejercicio0211.utilidades.DateUtils;
import com.javier.ejercicio0211.utilidades.JdbcUtils;
import com.javier.ejercicio0211.utilidades.NumberUtils;

/**
 * cursos (id, título, fechaIni) y usuarios que asisten (id, nombre). 
 * En cada curso puede haber múltiples usuarios, y supondremos que cada usuario sólo puede 
 * participar en un curso. 
 * Permitie añadir cursos, añadir participantes a un curso 
 * y ver todos los datos de un curso (incluyendo lista de participantes).
 *
 */
public class App 
{
	final static String USER ="postgres";
	final static String PASSWORD ="postgres";
	final static String URI ="jdbc:postgresql://localhost:5432/dia03";
	
    public static void main( String[] args )
    {    	
        String opcion;
        
        do {
        	mostrarMenu();
        	opcion = pedirDato("opcion").toLowerCase();      		
			lanzarOpcion(opcion);          	      	
        }while (!opcion.equals("s"));    	
    }
    
    private static void mostrarMenu() {
    	System.out.println("1-Anyadir curso");
    	System.out.println("2-Anyadir participante a un curso");
    	System.out.println("3-Listar datos curso");
    	System.out.println("4-Listar datos participante");
    	System.out.println("s-Salir");
    }
    
    private static void lanzarOpcion(String opcion){
    	switch(opcion) {
    		case "1": anyadirCurso(); break;
    		case "2": anyadirUsuarioACurso(); break;
    		case "3": listarCurso(); break;
    		case "4": listarParticipante(); break;
    		case "s": System.out.println("Hasta la proxima"); break;
			default: System.out.println("Opcion incorrecta"); break; 
    	}
    }
    
    private static void anyadirCurso() {    	
    	
    	String titulo = pedirDatoNoVacio("titulo");
    	String fecha = pedirDato("fecha de inicio");
    	LocalDate fechaIni = null;
    	if (!DateUtils.checkDate(fecha)) {
    		System.out.println("Formato de fecha incorrecto (yyyy-MM-dd)");
    	} else {
    		fechaIni = DateUtils.formatDate(fecha);
    	}
    		
    	String sql = "insert into cursosMM(titulo, fechaIni) values(?, ?);";
    	try {
    		JdbcUtils.conexion(URI, USER, PASSWORD);
    		
	    	int resultado = JdbcUtils.preparedStatementInsertUpdateDelete(sql, titulo, fechaIni);
	    	if (resultado > 0)
	    		System.out.println("Insercion correcta");
	    	else
	    		System.out.println("Error al insertar registro");  
    	}catch (SQLException e) {
    		e.printStackTrace();
    	} finally {    	
    		JdbcUtils.desconexion();
    	}
    }
    
    private static void anyadirUsuarioACurso() {
    	String usuario = pedirDatoNoVacio("id del usuario");
    	String curso = pedirDatoNoVacio("id del curso");
    	
    	int id_usuario = -1;
    	int id_curso = -1;
    	
    	if (NumberUtils.isNumeric(curso))
    		id_curso = Integer.parseInt(curso);
    	else
    		System.out.println("El curso es incorrecto");
    	
    	if (NumberUtils.isNumeric(usuario))
    		id_usuario = Integer.parseInt(usuario);
    	else
    		System.out.println("El usuario es incorrecto");   	

    	if (id_usuario > 0 && id_curso > 0) {
	    	String sql = "insert into participarMM(id_curso, id_usuario) values(?, ?);";
	    	try {    	
	    		JdbcUtils.conexion(URI, USER, PASSWORD);
	
				int resultado = 
						JdbcUtils.preparedStatementInsertUpdateDelete(sql, id_curso, id_usuario); 
				if (resultado > 0)
					System.out.println("Usuario anyadido correctamente al curso");
				else
					System.out.println("Error al anyadir el usuario al curso");
	    		
	    	}catch (SQLException e) {
	    		e.printStackTrace();
	    	}finally {
	    		JdbcUtils.desconexion();
	    	}    
    	}
    }
    
    private static void listarCurso() {
    	String sql = "select * from cursosMM";
    	JdbcUtils.conexion(URI, USER, PASSWORD);    	
    	try {
    		ResultSet rs = JdbcUtils.devolverResultSet(sql);
    		// muestra todos los cursos
	    	while (rs.next()) {
	    		System.out.println(rs.getInt("id") + ". " + rs.getString("titulo"));
	    	}
    	
	    	String id_curso = pedirDato("numero del curso");
	    	
	    	sql = "select * from cursosMM where id=" + id_curso;
	    	rs = JdbcUtils.devolverResultSet(sql);
	    	int resultados = 0;
	    	if (rs.next()) {
	    		resultados++;
	    		// muestra el curso seleccionado
	    		System.out.println(rs.getInt(1) + ". " + rs.getString(2) + ", " +
	    				rs.getString(3));
	    	}	  
	    	if (resultados == 0) {
    			System.out.println("No existe el curso introducido");
	    	} else {	    	
	    	
		    	sql = "select u.nombre from usuariosMM u inner join participarMM p"
		    			+ " on p.id_usuario=u.id and p.id_curso=?;";
		    	
	    		rs = JdbcUtils.preparedStatementSelect(sql, Integer.parseInt(id_curso));
	    		resultados = 0;
	    		while (rs.next()) {
	    			resultados++;
	    			// muestra los participantes en el curso seleccionado
	    			System.out.println("\t" + rs.getString("nombre"));
	    		}
	    		if (resultados == 0)
	    			System.out.println("\tNo se han encontrado participantes");
	    	}
	    	
    	}catch(SQLException e) {
    		e.printStackTrace();
    	}finally {
        	JdbcUtils.desconexion();
    	}
    }
    
    private static void listarParticipante() {
    	String sql = "select * from usuariosMM";
    	JdbcUtils.conexion(URI, USER, PASSWORD);    	
    	try {
    		ResultSet rs = JdbcUtils.devolverResultSet(sql);
    		// muestra todos los cursos
	    	while (rs.next()) {
	    		System.out.println(rs.getInt("id") + ". " + rs.getString("nombre"));
	    	}
    	
	    	String id_usuario = pedirDato("numero del usuario");
	    	
	    	sql = "select * from usuariosMM where id=" + id_usuario;
	    	rs = JdbcUtils.devolverResultSet(sql);
	    	int resultados = 0;
	    	if (rs.next()) {
	    		resultados++;
	    		// muestra el usuario seleccionado
	    		System.out.println(rs.getInt(1) + ". " + rs.getString(2));
	    	}	  
	    	if (resultados == 0) {
    			System.out.println("No existe el usuario introducido");
	    	} else {	    	
	    	
		    	sql = "select c.titulo from cursosMM c inner join participarMM p"
		    			+ " on p.id_curso=c.id and p.id_usuario=?;";
		    	
	    		rs = JdbcUtils.preparedStatementSelect(sql, Integer.parseInt(id_usuario));
	    		resultados = 0;
	    		while (rs.next()) {
	    			resultados++;
	    			// muestra los cursos en el usuario seleccionado
	    			System.out.println("\t" + rs.getString("titulo"));
	    		}
	    		if (resultados == 0)
	    			System.out.println("\tNo se han encontrado cursos");
	    	}
	    	
    	}catch(SQLException e) {
    		e.printStackTrace();
    	}finally {
        	JdbcUtils.desconexion();
    	}
    }
    
    
    private static String pedirDato(String dato) {
    	Scanner sc = new Scanner(System.in);
    	
    	System.out.print("Introduce " + dato + ": ");
    	return sc.nextLine();
    }
    
    private static String pedirDatoNoVacio(String dato) {
    	String datoNoVacio;
    	do {
    		datoNoVacio = pedirDato(dato);
    		if (datoNoVacio.isEmpty())
    			System.out.println(dato + " no puede estar vacío");
    	}while (datoNoVacio.isEmpty());
    	
    	return datoNoVacio;
    }
}
