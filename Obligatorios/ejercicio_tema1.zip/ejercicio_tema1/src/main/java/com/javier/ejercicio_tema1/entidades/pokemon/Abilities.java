package com.javier.ejercicio_tema1.entidades.pokemon;

import java.util.List;
import java.util.stream.Collectors;

/**
 * clase necesaria para extraer Json pokemon
 * @author Javier Gimenez Muñoz
 *
 */
public class Abilities {

	private Ability ability;

	public Abilities(Ability ability) {
		super();
		this.ability = ability;
	}

	public Ability getAbility() {
		return ability;
	}
	
	@Override
	public String toString() {
		return ability.toString();
	}
}
