package com.javier.ejercicio_tema1.entidades.pokemon;

/**
 * clase necesaria para extraer Json pokemon
 * @author Javier Gimenez Muñoz
 *
 */
public class Move {

	private String name;
	
	public Move(String name, String url) {
		super();
		this.name = name;
	}

	public String getName() {
		return name;
	}

	@Override
	public String toString() {
		return name;
	}	
	
}
