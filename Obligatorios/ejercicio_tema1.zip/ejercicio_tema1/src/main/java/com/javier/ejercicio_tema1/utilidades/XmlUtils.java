package com.javier.ejercicio_tema1.utilidades;

import java.sql.Timestamp;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import com.javier.ejercicio_tema1.entidades.weatherMap.Coord;
import com.javier.ejercicio_tema1.entidades.weatherMap.Main;
import com.javier.ejercicio_tema1.entidades.weatherMap.Weather;
import com.javier.ejercicio_tema1.entidades.weatherMap.WeatherMap;

/**
 * metodos para operar con ficheros xml
 * @author Javi
 *
 */
public class XmlUtils {

	/**
	 * procesa los datos de la api openweathermap 
	 * @param ciudad
	 * @return
	 */
	public static WeatherMap procesarOpenWeather(String ciudad) throws Exception{
		WeatherMap weatherMap = null;
		String url = "https://api.openweathermap.org/data/2.5/"
				+ "weather?mode=xml&q="+ciudad+"&appid=94b4a8f5118f3a7c4883ce72d123d052";
		
		Timestamp ts = null;
		double lon = 0, lat = 0, temp = 0;
		long id = 0;
		int humidity = 0;
		String description = "", icon = "", dt = "";
		List<Weather> weatherList = new ArrayList<>();			
		
		DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
		DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
		Document doc = dBuilder.parse(url);  // Comprueba que es un XML valido
		doc.getDocumentElement().normalize();
		
		NodeList nList = doc.getElementsByTagName("coord");
		Node nNode = nList.item(0);
		if (nNode.getNodeType() == Node.ELEMENT_NODE) {
			Element eElement = (Element) nNode;		
			lon = Double.parseDouble(eElement.getAttribute("lon"));
			lat = Double.parseDouble(eElement.getAttribute("lat"));	
		}
		
		nList = doc.getElementsByTagName("temperature");
		nNode = nList.item(0);
		if (nNode.getNodeType() == Node.ELEMENT_NODE) {
			Element eElement = (Element) nNode;
			temp = Double.parseDouble(eElement.getAttribute("value"));
		}
		
		nList = doc.getElementsByTagName("humidity");
		nNode = nList.item(0);
		if (nNode.getNodeType() == Node.ELEMENT_NODE) {
			Element eElement = (Element) nNode;
			humidity = Integer.parseInt(eElement.getAttribute("value"));
		}
		
		nList = doc.getElementsByTagName("weather");
		for (int i = 0; i < nList.getLength(); i++) {
			nNode = nList.item(i);
			if (nNode.getNodeType() == Node.ELEMENT_NODE) {
				Element eElement = (Element) nNode;
				id = Long.parseLong(eElement.getAttribute("number")); 
				description = eElement.getAttribute("value"); 
				icon = eElement.getAttribute("icon"); 	
				weatherList.add(new Weather(id, description, icon));
			}		
		}					
		
		weatherMap = new WeatherMap(
				new Coord(lon, lat), weatherList, 
				new Main(temp, humidity),ciudad);

		return weatherMap;
	}
}
