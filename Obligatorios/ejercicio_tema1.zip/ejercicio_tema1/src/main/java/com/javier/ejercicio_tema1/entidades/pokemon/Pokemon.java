package com.javier.ejercicio_tema1.entidades.pokemon;

import java.util.List;
import java.util.stream.Collectors;

import com.javier.ejercicio_tema1.entidades.weatherMap.Weather;

/**
 * clase pokemon con informacion de habilidades, movimientos, altura, peso
 * movimientos, experiencia base y estados
 * @author Javier Gimenez Muñoz
 *
 */
public class Pokemon {

	private List<Abilities> abilities;
	private String name;
	private int height;
	private int weight;
	private List<Moves> moves;
	private int base_experience;
	private List<Stats> stats;
	
	/**
	 * 
	 * @param name
	 * @param height
	 * @param weight
	 * @param abilities
	 * @param moves
	 * @param base_experience
	 * @param stats
	 */
	public Pokemon(String name, int height, int weight, List<Abilities> abilities,
			List<Moves> moves, int base_experience, List<Stats> stats) {
		super();
		this.name = name;
		this.height = height;
		this.weight = weight;
		this.abilities = abilities;
		this.moves = moves;
		this.base_experience = base_experience;
		this.stats = stats;
	}
	
	@Override
	public String toString(){		
		String texto = name + ", height: " + height + ", weight: " + weight + 
				", base experience: " + base_experience
				+ "\n\tabilities: [" +	abilities.stream().map(Abilities::toString)
						.collect(Collectors.joining(", ")) + "]"
				+ "\n\tmoves: [" + moves.stream().map(Moves::toString)
						.collect(Collectors.joining(", ")) + "]"
				+ "\n\tstat: " + stats.stream().map(Stats::toString)
						.collect(Collectors.joining("\n\tstat: "));		
		
		return texto;
	}
}
