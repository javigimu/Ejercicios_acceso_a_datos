package com.javier.ejercicio_tema1.entidades.weatherMap;

import java.io.Serializable;
import java.util.List;
import java.util.stream.Collectors;

/**
 * Clase para almacenar los datos obtenidos de la API openweathermap
 * @author Javier Gimenez Muñoz
 *
 */
public class WeatherMap implements Serializable {
	
	private Coord coord;
	private List<Weather> weather;
	private Main main;
	private String name;
	
	/**
	 * 
	 * @param coord
	 * @param weather
	 * @param main
	 * @param name
	 */
	public WeatherMap(Coord coord, List<Weather> weather, Main main, String name) {
		super();
		this.coord = coord;
		this.weather = weather;
		this.main = main;
		this.name = name;
	}	

	public Coord getCoord() {
		return coord;
	}

	public List<Weather> getWeather() {
		return weather;
	}

	public Main getMain() {
		return main;
	}

	public String getName() {
		return name;
	}
	
	public String getTemp() {
		return String.format("%.2f", main.getTemp()-273.15);
	}

	public String getHumidity() {
		return "" + main.getHumidity();
	}

	/**
	 *  muestra el nombre de la ciudad, temperatura, humedad 
	 *  y la informacion del array weather
	 */
	@Override
	public String toString() {
		String texto = name + " " + getTemp() + " grados, humedad actual: " 
				+ getHumidity() + "%\n\tweather: "
				+ weather.stream().map(Weather::toString)
					.collect(Collectors.joining("\n\tweather: "));
		
		return texto;
	}
}
