package com.javier.ejercicio_tema1.entidades.pokemon;

/**
 * clase necesaria para extraer Json pokemon
 * @author Javier Gimenez Muñoz
 *
 */
public class Stats {

	private int base_stat;
	private int effort;
	private Stat stat;
	
	public Stats(int base_stat, int effort, Stat stat) {
		super();
		this.base_stat = base_stat;
		this.effort = effort;
		this.stat = stat;
	}

	public int getBase_stat() {
		return base_stat;
	}

	public int getEffort() {
		return effort;
	}

	public Stat getStat() {
		return stat;
	}
	
	@Override
	public String toString() {
		return stat + "base_stat: " + base_stat + ", effort: " + effort;
	}
}
