package com.javier.ejercicio_tema1.entidades.weatherMap;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Objects;
import java.util.TreeMap;

/**
 * clase para manejar los datos necesario para analizar la evolución de la temperatura
 * en un rango de fechas
 * @author Javier Gimenez Muñoz
 *
 */
public class EvolucionTemperatura {
	
	private LocalDate fecha;
	private Map<LocalTime, Float> temperaturaPorHora;
	
	/**
	 * 
	 * @param fecha
	 */
	public EvolucionTemperatura(LocalDate fecha) {
		super();
		this.fecha = fecha;
		this.temperaturaPorHora = new HashMap<>();
	}	
	
	/**
	 * 
	 * @param fecha
	 * @param temperaturaPorHora
	 */
	public EvolucionTemperatura(LocalDate fecha, Map<LocalTime, Float> temperaturaPorHora) {
		super();
		this.fecha = fecha;
		this.temperaturaPorHora = temperaturaPorHora;
	}


	public LocalDate getFecha() {
		return fecha;
	}

	public Map<LocalTime, Float> getTemperaturaPorHora() {
		return temperaturaPorHora;
	}	
	

	public void setTemperaturaPorHora(Map<LocalTime, Float> temperaturaPorHora) {		
		temperaturaPorHora.entrySet().stream().forEach(entry ->
				this.temperaturaPorHora.put(entry.getKey(), entry.getValue()));
	}

	@Override
	public int hashCode() {
		return Objects.hash(fecha);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		EvolucionTemperatura other = (EvolucionTemperatura) obj;
		return Objects.equals(fecha, other.fecha);
	}

	@Override
	public String toString() {
		TreeMap mapaOrdenado = new TreeMap<>();
		mapaOrdenado.putAll(temperaturaPorHora);		

		return fecha + " " + mapaOrdenado;		
			
		/*return fecha + " [ " + temperaturaPorHora.entrySet().stream()
				.map(entry -> "{" + entry.getKey() + " -> " + entry.getValue() + "}")
				.collect(Collectors.joining(" ")) + " ]";*/		
	}

}
