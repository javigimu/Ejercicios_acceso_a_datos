package com.javier.ejercicio_tema1.entidades.weatherMap;

import java.io.Serializable;

/**
 * clase para gestionar el array Weather de la API openweathermap
 * @author Javier Gimenez Muñoz
 *
 */
public class Weather implements Serializable{
	private long id;
	private String main;
	private String description;
	private String icon;
	
	/**
	 * 
	 * @param id
	 * @param main
	 * @param description
	 * @param icon
	 */
	public Weather(long id, String main, String description, String icon) {
		super();
		this.id = id;
		this.main = main;
		this.description = description;
		this.icon = icon;
	}

	public Weather (long id, String description, String icon)
	{
		this(id, "", description, icon);
	}
	
	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getMain() {
		return main;
	}

	public void setMain(String main) {
		this.main = main;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getIcon() {
		return icon;
	}

	public void setIcon(String icon) {
		this.icon = icon;
	}

	@Override
	public String toString() {
		return "[id=" + id + ", " + main + ", " + description + ", icon=" + icon + "]";
	}		
	
}
