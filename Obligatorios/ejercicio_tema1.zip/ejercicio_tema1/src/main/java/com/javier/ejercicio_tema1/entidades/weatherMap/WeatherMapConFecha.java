package com.javier.ejercicio_tema1.entidades.weatherMap;

import java.io.Serializable;
import java.time.LocalDate;

/**
 * clase para extraer informacion del fichero json obtenido desde apiweathermap
 * @author Javier Gimenez Muñoz
 *
 */
public class WeatherMapConFecha implements Serializable{

	private LocalDate fechaActual;
	private WeatherMap weatherMap;
	
	public WeatherMapConFecha( WeatherMap weatherMap) {
		super();
		this.fechaActual = LocalDate.now();
		this.weatherMap = weatherMap;
	}

	public LocalDate getFechaActual() {
		return fechaActual;
	}

	public WeatherMap getWeatherMap() {
		return weatherMap;
	}

	@Override
	public String toString() {
		return fechaActual + " -> " + weatherMap.toString();
	}	
	
}
