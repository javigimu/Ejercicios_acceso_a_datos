package com.javier.ejercicio_tema1.utilidades;

import com.google.gson.Gson;
import com.javier.ejercicio_tema1.entidades.pokemon.Pokemon;
import com.javier.ejercicio_tema1.entidades.weatherMap.WeatherMap;

/**
 * metodos para operar con ficheros Json
 * @author Javier Gimenez Muñoz
 *
 */
public class JsonUtils {

	/**
	 * procesar Json de la api openweathermap a través de latitud y longitud
	 * @param latitud
	 * @param longitud
	 * @return
	 */
	public static WeatherMap procesarAPIJson(String latitud, String longitud) {
		
		String url = "https://api.openweathermap.org/data/2.5/"
				+ "weather?lat="+latitud+"&lon="+longitud+
				"&appid=5dd53db8602a962c4cd100f9853bdb06";

		return devolverObjetoGsonGenerico(url, WeatherMap.class);
	}
	
	
	public static Pokemon extraerInfoPokemon(String nombrePokemon) {
		
		String url = "https://pokeapi.co/api/v2/pokemon/" + nombrePokemon;
		return devolverObjetoGsonGenerico(url, Pokemon.class);		
	}
	
	
	
	/**
	 * Metódo genérico que dada una url con un json donde se encuentra un objeto
	 * devuelve un objeto de la clase asociada.
	 * Ejemplo de llamada: JsonUtils.devolverObjetoGsonGenerico("https://swapi.dev/api/people/1/?format=json",People2.class)
	 * @param <T> Nombre de la clase
	 * @param url
	 * @param clase Array de elementos del tipo de la clase
	 * @return
	 */
	public static <T> T devolverObjetoGsonGenerico(String url, Class<T> clase) {
        return new Gson().fromJson(InternetUtils.readUrl(url),clase);
	}
	
}
