package com.javier.ejercicio_tema1.utilidades;

import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.sql.Timestamp;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import com.javier.ejercicio_tema1.entidades.weatherMap.EvolucionTemperatura;

/**
 * metodos para operar con ficheros
 * @author Javier Gimenez Muñoz
 *
 */
public class FileUtils {

	/**
	 * escrbir lista de strings en un fichero
	 * @param datos
	 * @param fichero
	 * @throws IOException
	 */
	public static void escribirEnFichero(List<String> datos, String fichero) throws IOException {
		Path path = Paths.get(fichero);
		Files.write(path, datos, StandardCharsets.UTF_8);
	}
	
	/**
	 * leer un fichero en java 11
	 * @param rutaCompleta
	 * @return
	 */
	public static List<String> leerFichero(String rutaCompleta) {
		try {
			return Files.lines(Paths.get(rutaCompleta))
					.collect(Collectors.toList());
		}catch (IOException e) {
			e.printStackTrace();
		}
		return null;
	}
	
	
	public static List<EvolucionTemperatura> extraerDatosTemperaturas() {
		List<EvolucionTemperatura> datosTemperaturas = new ArrayList<>();
		if (new File("datos.csv").exists()) {
			List<String> datosFichero = leerFichero("datos.csv");	
			datosFichero.remove(0);
			Map<LocalTime, Float> mapaDeHoras = new HashMap<>();	
				
			LocalDate fechaInicial = DateUtils.formatDateTime(
					datosFichero.get(1).split(",")[5]).toLocalDate();
			for(int i = 0; i < datosFichero.size(); i++)
			{	    				
				LocalDateTime fecha = DateUtils.formatDateTime(
						datosFichero.get(i).split(",")[5]);
				LocalDate nuevaFecha = fecha.toLocalDate();				
				
				if (fechaInicial.equals(nuevaFecha)) {
					mapaDeHoras.put(fecha.toLocalTime(), 
							Float.parseFloat(datosFichero.get(i).split(",")[6]));					
				} else {
					EvolucionTemperatura et = new EvolucionTemperatura(fechaInicial);
					et.setTemperaturaPorHora(mapaDeHoras);
					if (!datosTemperaturas.contains(et))
						datosTemperaturas.add(et);
					fechaInicial = fecha.toLocalDate();
					mapaDeHoras.clear();
					mapaDeHoras.put(fecha.toLocalTime(), 
							Float.parseFloat(datosFichero.get(i).split(",")[6]));		
				}					   
			}
			EvolucionTemperatura et = new EvolucionTemperatura(fechaInicial);
			et.setTemperaturaPorHora(mapaDeHoras);
			if (!datosTemperaturas.contains(et))
				datosTemperaturas.add(et);
		}
		return datosTemperaturas;
	}
	
	/**
	 * obtiene el directorio de trabajo actual
	 * @return
	 */
	public static String obtenerDirectorioTrabajoActual() {
	    return System.getProperty("user.dir");
	}
	
}
