package com.javier.ejercicio_tema1.entidades.weatherMap;

import java.io.Serializable;

/**
 * clase para gestionar los campos longitud y latitud utilizados en el análisis de la API openweathermap
 * @author Javier Gimenez Muñoz
 *
 */
public class Coord implements Serializable{
	private double lon;
	private double lat;
	
	/**
	 * 
	 * @param lon
	 * @param lat
	 */
	public Coord(double lon, double lat) {
		super();
		this.lon = lon;
		this.lat = lat;
	}

	public double getLon() {
		return lon;
	}

	public void setLon(double lon) {
		this.lon = lon;
	}

	public double getLat() {
		return lat;
	}

	public void setLat(double lat) {
		this.lat = lat;
	}	
}
