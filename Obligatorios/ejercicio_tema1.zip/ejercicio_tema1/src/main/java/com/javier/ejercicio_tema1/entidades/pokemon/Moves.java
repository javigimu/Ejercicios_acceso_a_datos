package com.javier.ejercicio_tema1.entidades.pokemon;

import java.util.List;
import java.util.stream.Collectors;

/**
 * clase necesaria para extraer Json pokemon
 * @author Javier Gimenez Muñoz
 *
 */
public class Moves {

	private Move move;

	public Moves(Move move) {
		super();
		this.move = move;
	}

	public Move getMove() {
		return move;
	}
	
	@Override
	public String toString() {
		return move.toString();
	}
}
