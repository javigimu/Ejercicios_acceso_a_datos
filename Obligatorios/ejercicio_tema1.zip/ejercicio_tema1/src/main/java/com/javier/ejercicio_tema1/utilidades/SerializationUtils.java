package com.javier.ejercicio_tema1.utilidades;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.List;

/**
 * metodos para serializar y desserializar objetos genericos
 * @author Javier Gimenez Muñoz
 *
 */
public class SerializationUtils {

	/**
	 * Serializa una lista de objetos genericos
	 * @param <T>
	 * @param directorio
	 * @param nombreArchivo
	 * @param objetos
	 * @return
	 */
public static <T> boolean serializarListaObjetos(String nombreArchivo, List<T> objetos) {
		
		File fichero = new File(nombreArchivo);
		try (ObjectOutputStream ficheroObjetos = new ObjectOutputStream(
					new FileOutputStream(fichero))){
			
			ficheroObjetos.writeObject(objetos);  // Serializa
			return true;
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return false;
	}
	
	/**
	 * DesSerializa una lista de objetos genericos
	 * @param <T>
	 * @param directorio
	 * @param nombreArchivo
	 * @return
	 */
	public static <T> List<T> desSerializarListaObjetos(String nombreArchivo) {
		
		File fichero = new File(nombreArchivo);
		try (FileInputStream ficheroSalida = new FileInputStream(fichero);
			ObjectInputStream ficheroObjetos = new ObjectInputStream(ficheroSalida)){
			
			List<T> objetos = (List<T>) ficheroObjetos.readObject();  // DesSerializa
			return objetos;
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} 
		return null;
	}
}
