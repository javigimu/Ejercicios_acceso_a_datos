package com.javier.ejercicio_tema1;

import java.io.File;
import java.io.IOException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.stream.Collectors;

import com.javier.ejercicio_tema1.entidades.pokemon.Pokemon;
import com.javier.ejercicio_tema1.entidades.weatherMap.EvolucionTemperatura;
import com.javier.ejercicio_tema1.entidades.weatherMap.WeatherMap;
import com.javier.ejercicio_tema1.entidades.weatherMap.WeatherMapConFecha;
import com.javier.ejercicio_tema1.utilidades.DateUtils;
import com.javier.ejercicio_tema1.utilidades.FileUtils;
import com.javier.ejercicio_tema1.utilidades.JsonUtils;
import com.javier.ejercicio_tema1.utilidades.SerializationUtils;
import com.javier.ejercicio_tema1.utilidades.XmlUtils;

/**
 * @autor Javier Gimenez Muñoz
 * Aplicación para conectar con la API openweathermap y realizar diferentes consultas  
 *
 */
public class App 
{
	public static final String FICHERO_SERIALIZADO = "weatherMap.dat";
	
    public static void main( String[] args )
    {
    	Scanner sc = new Scanner(System.in);
    	boolean salir = false;    	
    	WeatherMap weatherMap = null;
    	List<EvolucionTemperatura> datosTemperaturas = null;
    	List<WeatherMapConFecha> listaWeather = null;
    	if (new File(FICHERO_SERIALIZADO).exists()) 
    			SerializationUtils.desSerializarListaObjetos(FICHERO_SERIALIZADO);
    	    	
    	do {
    		mostrarMenu();
    		String opcion = recogerOpcion(sc);    		
    		switch(opcion) {
	    		case "1": 
	    			String latitud = pedirDato(sc, "latitud");
	    			String longitud = pedirDato(sc, "longitud");
    				weatherMap = JsonUtils.procesarAPIJson(latitud, longitud); 
    				if (weatherMap != null)
    					mostrarInfoWeather(weatherMap);

	    			break;	
	    			
	    		case "2": 
	    			String nombreCiudad = pedirDato(sc, "nombre de ciudad");
	    			try {
	    				weatherMap = XmlUtils.procesarOpenWeather(nombreCiudad);
	    				mostrarInfoWeather(weatherMap);	 
	    			}catch (Exception e) {
	    				System.err.println("Ciudad no encontrada");
	    			}	    			
	    			break;
	    		
	    		case "3": 
	    		
	    			try {
	    				mostrarInformeEvolucion(sc, datosTemperaturas);	
	    			}catch(IOException ioe) {
	    				ioe.printStackTrace();
	    			}
	    			break;
	    		
	    		case "4": 
	    			serializarUltimaConsulta(listaWeather, weatherMap);
	    			break;
	    			
	    		case "5": 
	    			if (new File(FICHERO_SERIALIZADO).exists()) {
		    			listaWeather = SerializationUtils.desSerializarListaObjetos(		        					 
		        					FICHERO_SERIALIZADO);
		    				listaWeather.forEach(System.out::println);
	    			}else {
	    				System.err.println("El fichero "+ FICHERO_SERIALIZADO + " no existe");
	    			}
	    			break;
	    			
	    		case "6": 
	    			String nombrePokemon = pedirDato(sc, "nombre de pokemon");
    				Pokemon pokemon = JsonUtils.extraerInfoPokemon(nombrePokemon);
    				if (pokemon != null)
    					System.out.println(pokemon);
	    				
	    			break;
	    		case "s": salir = despedidaSalir(); break;
				default: System.err.println("Opcion incorrecta");				
    		}    		
    	}while (!salir);
    }
    
    /**
     * serializa la lista de objectos WeatherMapConFecha
     * si ya existe un objeto del mismo dia, se sustituye y sino se añade a la lista
     * @param listaWeather
     * @param weatherMap
     * @return
     */
    public static boolean serializarUltimaConsulta(List<WeatherMapConFecha> listaWeather, 
    		WeatherMap weatherMap) {
    	
    	if (weatherMap != null) {
	    	WeatherMapConFecha weatherMapConFecha = new WeatherMapConFecha(weatherMap);
	    	
	    	if (listaWeather == null) {    		
	    		listaWeather = new ArrayList<>();
	    		 		 		
	    	} else if (listaWeather.get(listaWeather.size()-1).getFechaActual().equals(
	    				weatherMapConFecha.getFechaActual())) {    			
	    			listaWeather.remove(listaWeather.size()-1);
			}
	    	listaWeather.add(weatherMapConFecha);   	
	    	
	    	if (SerializationUtils.serializarListaObjetos(FICHERO_SERIALIZADO, listaWeather)) { 
	    		System.out.println("Serialización correcta");
	    		return true;
	    	}
    	}
    	return false;
    }
    
    /**
     * muestra el informe de evolución de temperatura filtrando por rango de fechas
     * @param datosTemperaturas
     * @throws IOException 
     */
    private static void mostrarInformeEvolucion(Scanner sc, 
    		List<EvolucionTemperatura> datosTemperaturas) throws IOException {
    	
		System.out.println("Introduce el rango de fechas en formato yyyy-MM-dd");
		String fechaInicial = pedirDato(sc, "fecha inicial");
		String fechaFinal = pedirDato(sc, "fecha final");
		
		if (datosTemperaturas == null) {
			System.out.println("Extrayendo datos del fichero....");
			datosTemperaturas = FileUtils.extraerDatosTemperaturas();
			System.out.println("Extraccion correcta");
		}
		
		if (DateUtils.checkDate(fechaInicial.trim()) && 
				DateUtils.checkDate(fechaFinal.trim())) {

			if (!DateUtils.isCorrectRange(DateUtils.formatDate(fechaInicial), 
					DateUtils.formatDate(fechaFinal))) {
				String aux = fechaInicial;
				fechaInicial = fechaFinal;
				fechaFinal = aux;
			}
			List<EvolucionTemperatura> lineasInforme = 
					obtenerInformeEvolucion(datosTemperaturas, 
					DateUtils.formatDate(fechaInicial),
					DateUtils.formatDate(fechaFinal));	
			
			lineasInforme.forEach(System.out::println);
			List<String> lineas = lineasInforme.stream()
					.map(l -> l.toString()).collect(Collectors.toList());
			FileUtils.escribirEnFichero(lineas,	"informe.txt");
			System.out.println("Informe almacenado en el fichero informe.txt");

		}else {
			System.out.println("Las fechas no estan en el formato correcto");
		}
    }
    
	/**
	 * obtiene el informe con la evolucion de temperaturas entre dos fichas, ambas incluidas
	 * @param datosTemperaturas
	 * @param fechaInicial
	 * @param fechaFinal
	 * @return
	 */
	private static List<EvolucionTemperatura> obtenerInformeEvolucion(
			List<EvolucionTemperatura> datosTemperaturas, 
			LocalDate fechaInicial, LocalDate fechaFinal) {
				
		List<EvolucionTemperatura> datos = datosTemperaturas.stream()
					.filter(et -> et.getFecha().equals(fechaInicial) ||
							et.getFecha().equals(fechaFinal) ||
							(et.getFecha().isAfter(fechaInicial) 
							&& et.getFecha().isBefore(fechaFinal)))
					.collect(Collectors.toList());	
		datos.sort((e1, e2) -> e1.getFecha().compareTo(e2.getFecha()));
		return datos;
	}
    
    
    /**
     * muestra el nombre de la ciudad, temperatura y humedad
     * @param weatherMap
     */
    private static void mostrarInfoWeather(WeatherMap weatherMap) 
    {
    	System.out.println(weatherMap);
    }
    
    
    /**
     * Muestra el menu principal
     */
    private static void mostrarMenu() 
    {
    	System.out.println("1. Introducir longitud y latitud");  
    	System.out.println("2. Introducir nombre ciudad");
    	System.out.println("3. Mostrar evolución de temperaturas desde \"datos.csv\"");
    	System.out.println("4. Serializar los datos de la última búsqueda");
    	System.out.println("5. DesSerializar datos y mostrar");    	
    	System.out.println("6. Buscar información de un Pokemon por nombre en pokeapi");
    	System.out.println("s. Salir");
    }   
    
    
    /**
     * función para pedir un dato al cliente
     * @param sc
     * @param dato
     * @return
     */
    private static String pedirDato(Scanner sc, String dato) 
    {
    	System.out.print("Introduce " + dato + ": ");
    	return sc.nextLine();
    }
    
    /** 
     * Recoge la opcion introducida por el usuario
     * @param sc Scanner de la consola
     * @return String tecleado por el usuario convertido a minuscula
     */
    private static String recogerOpcion(Scanner sc) 
    {
    	System.out.println();
    	System.out.print("Introduce una opcion: ");
    	return sc.nextLine().toLowerCase();
    }
    
    /**
     * Muestra una despedida al usuario
     * @return true
     */
    private static boolean despedidaSalir()
    {
    	System.out.println("Hasta la proxima!"); 
    	return true;
    }
    
}
