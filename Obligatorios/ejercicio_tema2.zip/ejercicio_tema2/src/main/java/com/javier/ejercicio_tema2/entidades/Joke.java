package com.javier.ejercicio_tema2.entidades;

public class Joke {
	
	private int id;
	private String lang;
	private String category;
	private String type;
	private String joke; 	 // chiste de tipo single
	private String setup; 	 // chiste de tipo twopart pregunta
	private String delivery; // chiste de tipo twopart respuesta
	private Flag flags;
	
	public Joke(int id, String lang, String category, String type,
			String joke, String setup, String delivery,	Flag flags) {
		super();
		this.id = id;
		this.lang = lang;
		this.category = category;
		this.type = type;
		this.joke = joke;
		this.setup = setup;
		this.delivery = delivery;
		this.flags = flags;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getLang() {
		return lang;
	}

	public void setLang(String lang) {
		this.lang = lang;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getJoke() {
		return joke;
	}

	public void setJoke(String joke) {
		this.joke = joke;
	}

	public String getSetup() {
		return setup;
	}

	public void setSetup(String setup) {
		this.setup = setup;
	}

	public String getDelivery() {
		return delivery;
	}

	public void setDelivery(String delivery) {
		this.delivery = delivery;
	}

	public Flag getFlags() {
		return flags;
	}

	public void setFlags(Flag flags) {
		this.flags = flags;
	}

	@Override
	public String toString() {
		return "Joke [id=" + id + ", lang=" + lang + ", category=" + category 
				+ ", type=" + type + ", joke=" + joke + ", setup=" + setup 
				+ ", delivery=" + delivery + ", flags=" + flags + "]";
	}
	
	
	
}
