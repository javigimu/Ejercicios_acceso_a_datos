package com.javier.ejercicio_tema2.entidades;

public class Flag {
	
	private boolean nsfw;
	private boolean religious;
	private boolean political;
	private boolean racist;
	private boolean sexist;
	private boolean explicit;
	
	public Flag(boolean nsfw, boolean religious, boolean political, 
			boolean racist, boolean sexist, boolean explicit) {
		super();
		this.nsfw = nsfw;
		this.religious = religious;
		this.political = political;
		this.racist = racist;
		this.sexist = sexist;
		this.explicit = explicit;
	}

	public boolean isNsfw() {
		return nsfw;
	}

	public boolean isReligious() {
		return religious;
	}

	public boolean isPolitical() {
		return political;
	}

	public boolean isRacist() {
		return racist;
	}

	public boolean isSexist() {
		return sexist;
	}

	public boolean isExplicit() {
		return explicit;
	}

	@Override
	public String toString() {
		return "Flag [nsfw=" + nsfw + ", religious=" + religious + ", political=" + political + ", racist=" + racist
				+ ", sexist=" + sexist + ", explicit=" + explicit + "]";
	}
	

}
