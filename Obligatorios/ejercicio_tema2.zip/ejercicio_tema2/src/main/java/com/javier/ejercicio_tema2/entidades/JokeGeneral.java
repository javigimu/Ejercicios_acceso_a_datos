package com.javier.ejercicio_tema2.entidades;

public class JokeGeneral {
	
	private int totalCount;
	private IdRange idRange;
	
	public JokeGeneral(int totalCount, IdRange idRange) {
		super();
		this.totalCount = totalCount;
		this.idRange = idRange;
	}

	public int getTotalCount() {
		return totalCount;
	}

	public IdRange getIdRange() {
		return idRange;
	}
}
