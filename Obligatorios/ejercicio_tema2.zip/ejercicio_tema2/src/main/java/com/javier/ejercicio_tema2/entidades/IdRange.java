package com.javier.ejercicio_tema2.entidades;

public class IdRange {

	private int[] cs;
	private int[] es;
	private int[] de;
	private int[] pt;
	private int[] en;
	private int[] fr;
	
	public IdRange(int[] cs, int[] es, int[] de, int[] pt, int[] en, int[] fr) {
		super();
		this.cs = cs;
		this.es = es;
		this.de = de;
		this.pt = pt;
		this.en = en;
		this.fr = fr;
	}

	public int getMaxCs() {
		return cs[1];
	}

	public int getMaxEs() {
		return es[1];
	}

	public int getMaxDe() {
		return de[1];
	}

	public int getMaxPt() {
		return pt[1];
	}

	public int getMaxEn() {
		return en[1];
	}

	public int getMaxFr() {
		return fr[1];
	}
	
	
}
