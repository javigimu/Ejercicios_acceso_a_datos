package com.javier.ejercicio_tema2.entidades;

public class MainJoke {
	private JokeGeneral jokes;

	public MainJoke(JokeGeneral jokes) {
		super();
		this.jokes = jokes;
	}

	public JokeGeneral getJokes() {
		return jokes;
	}
	
	public int getTotalCount() {
		return jokes.getTotalCount();
	}
	
	public int getTotalCs() {
		return jokes.getIdRange().getMaxCs();
	}
	
	public int getTotalEs() {
		return jokes.getIdRange().getMaxEs();
	}
	
	public int getTotalDe() {
		return jokes.getIdRange().getMaxDe();
	}
	
	public int getTotalEn() {
		return jokes.getIdRange().getMaxEn();
	}
	
	public int getTotalFr() {
		return jokes.getIdRange().getMaxFr();
	}
	
	public int getTotalPt() {
		return jokes.getIdRange().getMaxPt();
	}
}
