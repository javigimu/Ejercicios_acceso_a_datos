package com.javier.ejercicio_tema2;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import com.javier.ejercicio_tema2.entidades.Joke;
import com.javier.ejercicio_tema2.entidades.MainJoke;
import com.javier.ejercicio_tema2.utilidades.JdbcUtils;
import com.javier.ejercicio_tema2.utilidades.JsonUtils;

/**
 * @author Javier Gimenez Muñoz
 * practica obligatoria tema 2
 *
 */
public class App 
{
	private static MainJoke datosGeneralesJoke;
	private static List<Joke> listaChistes = new ArrayList<>();
	private static int totalChistes;
	private static int contadorChistesDescargados = 0;
	
	final static String USER ="postgres";
	final static String PASSWORD ="postgres";
	final static String URI ="jdbc:postgresql://localhost:5432/jokes";
	
    public static void main( String[] args )
    {
    	Scanner sc = new Scanner(System.in);
    	boolean salir = false;
    	
    	/*
    	// extraer informacion general sobre los chistes de jokeApi
    	// para obtener total de chistes por idioma y total chistes en api
    	extraerInformacionGeneralJokeApi();
    	
    	// extraer chistes desde la api
        extraerChistesJokeApi();        
    	
    	// extraer chistes desde los ficheros
    	//extraerChistesDeFichero();
        
    	vaciarTablasJokes();
    	llenarTablasJokes();
    	*/
    	
    	do {
    		mostrarMenu();
    		String opcion = pedirDato("una opcion", sc).toLowerCase();
    		salir = ejecutarOpcion(opcion, sc);
    		
    	} while (!salir);
    }
    
    /**
     * 
     * @param opcion
     * @return
     */
    private static boolean ejecutarOpcion(String opcion, Scanner sc) {
    	boolean salir = false;    	
    	switch (opcion) {
	    	case "1": vaciarYLlenarBd(); break;
	    	case "2": anyadirChisteStatement(sc); break;
	    	case "3": anyadirChistePreparedStatement(sc); break;
	    	case "4": buscarChistesPorTexto(sc); break;
	    	case "5": listarChistesSinFlags(sc); break;
	    	case "s": System.out.println("Hasta la proxima!"); salir = true; break;
	    	default: System.out.println("Opcion incorrecta"); break;
    	}    	
    	return salir;
    }
    
    /**
     * muestra todos los chistes que no tienen ningun flag
     * ordenados por idioma y id_chiste
     */
    private static void listarChistesSinFlags(Scanner sc) {
    	JdbcUtils.conexion(URI, USER, PASSWORD);
		ResultSet rs = JdbcUtils.ejecutarCallableTable("listar_chistes_sin_flags()", "");
		if (rs != null) {
			System.out.println("Chistes sin flags");
			int cantidadChistes = 0;
			try {
				while(rs.next()) {
					if (cantidadChistes > 0 && (cantidadChistes % 40 == 0)) {
						System.out.println("Pulse una tecla para continuar");
						sc.nextLine();
					}
					
					cantidadChistes++;
					// Mostrando solo el texto de los chistes
					if (rs.getString("id_type").equals("single")) {
						System.out.println(rs.getString("joke"));
					} else if (rs.getString("id_type").equals("twopart")) {
						System.out.println(rs.getString("setup") + "\n" + rs.getString("delivery"));
					}
					
					/*Mostrando todos los datos
					if (rs.getString("id_type").equals("single")) {
						System.out.println("Idioma: " + rs.getString("id_idioma") + "\n" 
								+ "Id_chiste: " + rs.getInt("id_chiste") +"\n" 
								+ "Chiste: " + rs.getString("joke") + "\n" 
								+ "Categoria: " + rs.getString("id_category") + "\n"
								+ "Tipo: " + rs.getString("id_type"));
					} else if (rs.getString("id_type").equals("twopart")) {
						System.out.println("Idioma: " + rs.getString("id_idioma") + "\n" 
								+ "Id_chiste: " + rs.getInt("id_chiste") +"\n" 
								+ "Pregunta: " + rs.getString("setup") + "\n" 
								+ "Respuesta: " + rs.getString("delivery") + "\n"
								+ "Categoria: " + rs.getString("id_category") + "\n"
								+ "Tipo: " + rs.getString("id_type"));
					}*/
					System.out.println();
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			JdbcUtils.desconexion();  
		}
    }
    
    /**
     * Búsqueda por texto. 
     * Crea en Postgres un procedimiento almacenado en lenguaje plpgsql que obtenga chistes 
     * que contengan el texto pasado. 
     * Utiliza este método para poder hacer búsquedas parciales 
     * (no sensibles a mayúsculas) de los chistes 
     * (por ejemplo puedo buscar "Java" y me devolverá los chistes que contengan 
     * la palabra Java en su texto independientemente del idioma y los mostrará como 
     * resultados.Llama a este procedimiento almacenado mediante CallableStatement.
     * @param sc
     */
    private static void buscarChistesPorTexto(Scanner sc) {
    	String texto = pedirDato("texto para buscar chistes", sc);
    	JdbcUtils.conexion(URI, USER, PASSWORD);
		ResultSet rs = JdbcUtils.ejecutarCallableTable("buscar_chistes(?)", texto);
		if (rs != null) {
			System.out.println("Chistes que contienen el texto: " + texto);
			try {
				while(rs.next()) {
					// Mostrando solo el texto de los chistes
					if (rs.getString("id_type").equals("single")) {
						System.out.println(rs.getString("joke"));
					} else if (rs.getString("id_type").equals("twopart")) {
						System.out.println(rs.getString("setup") + "\n" + rs.getString("delivery"));
					}
					
					/*Mostrando todos los datos
					if (rs.getString("id_type").equals("single")) {
						System.out.println("Idioma: " + rs.getString("id_idioma") + "\n" 
								+ "Id_chiste: " + rs.getInt("id_chiste") +"\n" 
								+ "Chiste: " + rs.getString("joke") + "\n" 
								+ "Categoria: " + rs.getString("id_category") + "\n"
								+ "Tipo: " + rs.getString("id_type"));
					} else if (rs.getString("id_type").equals("twopart")) {
						System.out.println("Idioma: " + rs.getString("id_idioma") + "\n" 
								+ "Id_chiste: " + rs.getInt("id_chiste") +"\n" 
								+ "Pregunta: " + rs.getString("setup") + "\n" 
								+ "Respuesta: " + rs.getString("delivery") + "\n"
								+ "Categoria: " + rs.getString("id_category") + "\n"
								+ "Tipo: " + rs.getString("id_type"));
					}*/
					System.out.println();
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		JdbcUtils.desconexion();    	
    }
    
    /**
     * Anyadir chiste utilizando preparedStatement
     * @param sc
     */
    private static void anyadirChistePreparedStatement(Scanner sc) {
    	String categoria = pedirCategoria(sc);
    	int tipo = pedirTipo(sc); // 1-> single 2 -> twopart
    	String idioma = pedirIdioma(sc);
    	
    	List<String> listaFlags = new ArrayList<>();
    	String flag = "";
    	do {
    		flag = pedirFlags(sc);
    		if (!flag.isEmpty())
    			listaFlags.add(flag);
    	} while (!flag.isEmpty());
    	
    	String chiste = "";
    	String setup = "";
    	String delivery = ""; 
    	int id_chiste = -1;
    	if (tipo == 1) {
    		chiste = pedirDatoNoVacio("el texto del chiste", sc);
    	} else if (tipo == 2) {
    		setup = pedirDatoNoVacio("la primera parte del chiste", sc);
    		delivery = pedirDatoNoVacio("la segunda parte del chiste", sc);
    	}
    	
    	try {
    		JdbcUtils.conexion(URI, USER, PASSWORD);
    		// extraigo el ultimo id de chiste almacenado para el idioma seleccionado
    		String sqlIdChiste = "select max(id_chiste) from jokes where id_idioma='" 
    				+ idioma + "';";
    		ResultSet rs = JdbcUtils.devolverResultSet(sqlIdChiste);    		
    		if (rs.next()) {
    			id_chiste = rs.getInt(1) + 1;
    		}
    		
    		// inserto los datos del chiste
    		String sql = "";
    		int resultado = 0;
    		if (tipo == 1) {
    			sql = "insert into jokes(id_idioma, id_chiste, joke, id_category, id_type)"
    					+ " values(?, ?, ?, ?, ?);";  
    			resultado = JdbcUtils.preparedStatementInsertUpdateDelete(sql, 
        				idioma, id_chiste, chiste, categoria, "single");
    			
    		} else if (tipo == 2) {
    			sql = "insert into jokes(id_idioma, id_chiste, setup, delivery, "
    					+ "id_category, id_type) values(?, ?, ?, ?, ?, ?);";
    			resultado = JdbcUtils.preparedStatementInsertUpdateDelete(sql, 
        				idioma, id_chiste, setup, delivery, categoria, "twopart");
    		}    		
    		
    		if (resultado > 0)
    			System.out.println("Chiste insertado correctamente"); 
    		else
    			System.out.println("Error al insertar el chiste");
    		
    		// inserto los flags asociados al chiste
    		boolean insercionCorrectaFlags = false;
    		for (String f : listaFlags) {
    			sql = "insert into flags values('" + f + "', '" + idioma + "', " 
    					+ id_chiste + ");";
    			resultado = JdbcUtils.statementDML(sql);
    			if (resultado > 0)
    				insercionCorrectaFlags = true;
    		}
    	
    		
    	} catch (SQLException e) {
    		System.err.println("Error al insertar los datos: " + e.getMessage());
    	} finally {
    		JdbcUtils.desconexion();
    	}
    	
    }
    
    /**
     * Pide por consola los datos del nuevo (joke) chiste 
     * (categoría, flags, tipo, idioma y el texto del chiste). 
     * Si el chiste es tipo 1 (single) solo te pedirá un texto, 
     * si es de tipo 2 (twopart) te pedirá dos textos. 
     * Ofrece al usuario para todos los apartados un listado con las opciones disponibles.
     */    
    private static void anyadirChisteStatement(Scanner sc) {
    	String categoria = pedirCategoria(sc);
    	int tipo = pedirTipo(sc); // 1-> single 2 -> twopart
    	String idioma = pedirIdioma(sc);
    	
    	List<String> listaFlags = new ArrayList<>();
    	String flag = "";
    	do {
    		flag = pedirFlags(sc);
    		if (!flag.isEmpty())
    			listaFlags.add(flag);
    	} while (!flag.isEmpty());
    	
    	String chiste = "";
    	String setup = "";
    	String delivery = ""; 
    	int id_chiste = -1;
    	if (tipo == 1) {
    		chiste = pedirDatoNoVacio("el texto del chiste", sc);
    	} else if (tipo == 2) {
    		setup = pedirDatoNoVacio("la primera parte del chiste", sc);
    		delivery = pedirDatoNoVacio("la segunda parte del chiste", sc);
    	}
    	
    	try {
    		JdbcUtils.conexion(URI, USER, PASSWORD);
    		// extraigo el ultimo id de chiste almacenado para el idioma seleccionado
    		String sqlIdChiste = "select max(id_chiste) from jokes where id_idioma='" 
    				+ idioma + "';";
    		ResultSet rs = JdbcUtils.devolverResultSet(sqlIdChiste);    		
    		if (rs.next()) {
    			id_chiste = rs.getInt(1) + 1;
    		}
    		
    		// inserto los datos del chiste
    		String sql = "";
    		if (tipo == 1) {
    			sql = "insert into jokes(id_idioma, id_chiste, joke, id_category, "
    					+ "id_type) values('" + idioma + "', " + id_chiste + ", '" 
    					+ chiste + "', '" + categoria + "', 'single');";  
    		} else if (tipo == 2) {
    			sql = "insert into jokes(id_idioma, id_chiste, setup, delivery, "
    					+ "id_category, id_type) values('" + idioma + "', " + id_chiste 
    					+ ", '" + setup + "', '" + delivery + "', '" + categoria 
    					+ "', 'twopart');";  
    		}    		
    		int resultado = JdbcUtils.statementDML(sql);
    		if (resultado > 0)
    			System.out.println("Chiste insertado correctamente"); 
    		else
    			System.out.println("Error al insertar el chiste");
    		
    		// inserto los flags asociados al chiste
    		boolean insercionCorrectaFlags = false;
    		for (String f : listaFlags) {
    			sql = "insert into flags values('" + f + "', '" + idioma + "', " 
    					+ id_chiste + ");";
    			resultado = JdbcUtils.statementDML(sql);
    			if (resultado > 0)
    				insercionCorrectaFlags = true;
    		}
    	
    		
    	} catch (SQLException e) {
    		System.err.println("Error al insertar los datos: " + e.getMessage());
    	} finally {
    		JdbcUtils.desconexion();
    	}
    }
    
    /**
     * muestra las categorias y devuelve la seleccionada por el usuario si existe
     * sino, se devuelve una cadena vacia
     * @param sc
     * @return
     */
    private static String pedirFlags(Scanner sc) {
    	String sql = "select distinct id from flags;";
    	List<String> flags = new ArrayList<>();
    	
    	try {
    		JdbcUtils.conexion(URI, USER, PASSWORD);
	    	ResultSet rs = JdbcUtils.devolverResultSet(sql);
	    	
	    	while (rs.next()) {
	    		System.out.println(rs.getString("id"));
	    		flags.add(rs.getString("id"));
	    	}
    	} catch (SQLException e) {
    		System.err.println("Error al obtener los flags: " + e.getMessage());
    	} finally {
    		JdbcUtils.desconexion();
    	}
    	
    	boolean opcionCorrecta = true;
    	String flag;
    	do {
    		flag = pedirDato("flag o pulsa Enter para continuar", sc);
        	if (!flags.contains(flag) && !flag.isEmpty()) {
        		System.out.println("Flag incorrecto");
        		opcionCorrecta = false;   	
        	} else {
        		opcionCorrecta = true;
        	}
    	} while (!opcionCorrecta);
    	
    	return flag;
    }
    
    /**
     * muestra los idiomas y devuelve el seleccionado por el usuario 
     * @param sc
     * @return
     */
    private static String pedirIdioma(Scanner sc) {
    	String sql = "select * from languages;";
    	List<String> idiomas = new ArrayList<>();
    	
    	try {
    		JdbcUtils.conexion(URI, USER, PASSWORD);
	    	ResultSet rs = JdbcUtils.devolverResultSet(sql);
	    	
	    	while (rs.next()) {
	    		System.out.println(rs.getString("id"));
	    		idiomas.add(rs.getString("id"));
	    	}
    	} catch (SQLException e) {
    		System.err.println("Error al obtener los idiomas: " + e.getMessage());
    	} finally {
    		JdbcUtils.desconexion();
    	}
    	
    	boolean opcionCorrecta = true;
    	String idioma;
    	do {
    		idioma = pedirDato("idioma", sc);
        	if (!idiomas.contains(idioma)) {
        		System.out.println("Idioma incorrecto");
        		opcionCorrecta = false;   	
        	} else {
        		opcionCorrecta = true;
        	}
    	} while (!opcionCorrecta);
    	
    	return idioma;
    }
    
    /**
     * muestra los tipos y devuelve el seleccionado por el usuario 
     * 1 -> single
     * 2 -> twopart
     * @param sc
     * @return
     */
    private static int pedirTipo(Scanner sc) {
    	String sql = "select * from types;";
    	int contador = 0;
    	
    	try {
    		JdbcUtils.conexion(URI, USER, PASSWORD);
	    	ResultSet rs = JdbcUtils.devolverResultSet(sql);
	    	
	    	while (rs.next()) {
	    		contador++;
	    		System.out.println(contador + ". " + rs.getString("id")); 
	    	}
    	} catch (SQLException e) {
    		System.err.println("Error al obtener los tipos: " + e.getMessage());
    	} finally {
    		JdbcUtils.desconexion();
    	}
    	
    	boolean opcionCorrecta = true;
    	String tipo;
    	do {
    		tipo = pedirDato("tipo (1 - >single o 2 -> twopart)", sc);
        	if (!tipo.equals("1") && !tipo.equals("2")) {
        		System.out.println("Tipo incorrecto");
        		opcionCorrecta = false;   	
        	}else {
        		opcionCorrecta = true;
        	}
    	} while (!opcionCorrecta);
    	
    	return Integer.parseInt(tipo);
    }
    
    /**
     * muestra las categorias y devuelve la seleccionada por el usuario
     * @param sc
     * @return
     */
    private static String pedirCategoria(Scanner sc) {
    	String sql = "select * from categories;";
    	List<String> categorias = new ArrayList<>();
    	
    	try {
    		JdbcUtils.conexion(URI, USER, PASSWORD);
	    	ResultSet rs = JdbcUtils.devolverResultSet(sql);
	    	
	    	while (rs.next()) {
	    		System.out.println(rs.getString("id"));
	    		categorias.add(rs.getString("id"));
	    	}
    	} catch (SQLException e) {
    		System.err.println("Error al obtener las categorias: " + e.getMessage());
    	} finally {
    		JdbcUtils.desconexion();
    	}
    	
    	boolean opcionCorrecta = true;
    	String categoria;
    	do {
    		categoria = pedirDato("categoria", sc);
        	if (!categorias.contains(categoria)) {
        		System.out.println("Categoria incorrecta");
        		opcionCorrecta = false;   	
        	} else {
        		opcionCorrecta = true;
        	}
    	} while (!opcionCorrecta);
    	
    	return categoria;
    }
    
    /**
     * vacia y llena la base de datos, previa descarga de los mismos desde jokeApi
     */
    private static void vaciarYLlenarBd() {
    	extraerInformacionGeneralJokeApi();
        extraerChistesJokeApi();       
    	
    	// extraer chistes desde los ficheros
    	//extraerChistesDeFichero();
        
    	vaciarTablasJokes();
    	llenarTablasJokes();
    }
    
    /**
     * menu principal de la aplicacion
     */
    private static void mostrarMenu() {
    	System.out.println("1. Resetear base de datos");
    	System.out.println("2. Anyadir chiste statement");
    	System.out.println("3. Anyadir chiste preparedStatement");
    	System.out.println("4. Buscar chistes por texto");
    	System.out.println("5. Mostrar chistes sin flags");
    	System.out.println("s. Salir");
    }
    
    
    /**
     * llena las tablas con el contenido de la lista de chistes
     *  String id;
     *  String lang;
     *  String category;
     *  String type;
     *  String joke; 	 // chiste de tipo single
     *  String setup; 	 // chiste de tipo twopart pregunta
     *  String delivery; // chiste de tipo twopart respuesta
     *  Flag flags;
     */
    private static void llenarTablasJokes() {    	
    	
    	JdbcUtils.conexion(URI, USER, PASSWORD);
    	
    	listaChistes.forEach(j -> {
    		insertarCategoria(j); 
    		insertarTipo(j);
    		insertarLengua(j);
    		insertarChiste(j);
    		insertarFlag(j);
    	});
    	
    	System.out.println("Registros insertados correctamente");    	
    	JdbcUtils.desconexion();
    }
    
    /**
     * inserta un flag en la tabla flags de postgresql
     * @param j
     */
    private static void insertarFlag(Joke j) {   
    	
    	if (j.getFlags().isNsfw()) 
    		insertarFlag("nsfw", j.getLang(), j.getId());
    	
    	if (j.getFlags().isReligious()) 
    		insertarFlag("religious", j.getLang(), j.getId());
    	
    	if (j.getFlags().isPolitical()) 
    		insertarFlag("political", j.getLang(), j.getId());
    		
    	if (j.getFlags().isRacist()) 
    		insertarFlag("racist", j.getLang(), j.getId());
    	
    	if (j.getFlags().isSexist()) 
    		insertarFlag("sexist", j.getLang(), j.getId());
    	
    	if (j.getFlags().isExplicit()) 
    		insertarFlag("explicit", j.getLang(), j.getId());    			
    }
    
    /**
     * inserta un flag que se pasa por parametro con un chiste(lenguaje, id chiste)
     * @param flag
     * @param idioma
     * @param chiste
     */
    private static void insertarFlag(String flag, String idioma, int chiste) {
    	String sqlExiste = "select * from flags where id=? and idioma=? and chiste=?;";
    	
    	ResultSet rs = 
				JdbcUtils.preparedStatementSelect(sqlExiste, flag, idioma, chiste);    		
		try {
			if (!rs.next()) {
				String sql = "insert into flags values(?, ?, ?);"; 
				JdbcUtils.preparedStatementInsertUpdateDelete(sql, flag, idioma, chiste);
			}
		} catch (SQLException e) {
			System.out.println("Error al consultar la tabla");
		}
    }
    
    
    /**
     * inserta un chiste en la tabla jokes de postgresql
     * @param j
     */
    private static void insertarChiste(Joke j) {
    	String sqlExiste = "select * from jokes where id_idioma=? and id_chiste=?;";
    	ResultSet rs = 
				JdbcUtils.preparedStatementSelect(sqlExiste, j.getLang(), j.getId());
		try {
			if (!rs.next()) {
				String sql = "insert into jokes values(?, ?, ?, ?, ?, ?, ?);"; 
				JdbcUtils.preparedStatementInsertUpdateDelete(sql, j.getLang(), 
						j.getId(), j.getJoke(), j.getSetup(), j.getDelivery(),
						j.getCategory(), j.getType());
			}
		} catch (SQLException e) {
			System.out.println("Error al consultar la tabla");
		}
    }
    
    /**
     * inserta un lenguaje en la tabla languages de postgresql
     * @param j
     */
    private static void insertarLengua(Joke j) {
    	String sqlExiste = "select * from languages where id=?;";
    	ResultSet rs = 
				JdbcUtils.preparedStatementSelect(sqlExiste, j.getLang());
		try {
			if (!rs.next()) {
				String sql = "insert into languages values(?);"; 
				JdbcUtils.preparedStatementInsertUpdateDelete(sql, j.getLang());
			}
		} catch (SQLException e) {
			System.out.println("Error al consultar la tabla");
		}
    }
    
    /**
     * inserta un tipo en la tabla types de postgresql
     * @param j
     */
    private static void insertarTipo(Joke j) {
    	String sqlExiste = "select * from types where id=?;";
    	ResultSet rs = 
				JdbcUtils.preparedStatementSelect(sqlExiste, j.getType());
		try {
			if (!rs.next()) {
				String sql = "insert into types values(?);"; 
				JdbcUtils.preparedStatementInsertUpdateDelete(sql, j.getType());
			}
		} catch (SQLException e) {
			System.out.println("Error al consultar la tabla");
		}
    }
    
    /**
     * inserta una categoria en la tabla categories de postgresql
     * @param j
     */
    private static void insertarCategoria(Joke j) {
    	String sqlExiste = "select * from categories where id=?;";
    	ResultSet rs = 
				JdbcUtils.preparedStatementSelect(sqlExiste, j.getCategory());
		try {
			if (!rs.next()) {
				String sql = "insert into categories values(?);";
				JdbcUtils.preparedStatementInsertUpdateDelete(sql, j.getCategory());
			}
		} catch (SQLException e) {
			System.out.println("Error al consultar la tabla");
		}
    }
    
    /**
     * vacia el contenido de todas las tablas
     */
    private static void vaciarTablasJokes() {
    	boolean todoOk = true;
    	String error = "";
    	JdbcUtils.conexion(URI, USER, PASSWORD);
    	
    	String sql = "delete from flags;";  
		int resultado = JdbcUtils.statementDML(sql);
		if (resultado < 0) {
    		todoOk = false;
    		error += "flags ";
    	}
		sql = "delete from jokes;";  
		resultado = JdbcUtils.statementDML(sql);
		if (resultado < 0) {
    		todoOk = false;
    		error += "jokes ";
    	}
    	
    	sql = "delete from categories;";   
    	resultado = JdbcUtils.statementDML(sql);
    	if (resultado < 0) {
    		todoOk = false;
    		error += "categories ";
    	}
		sql = "delete from types;";  
		resultado = JdbcUtils.statementDML(sql);
		if (resultado < 0) {
    		todoOk = false;
    		error += "types ";
    	}
		sql = "delete from languages;";  
		resultado = JdbcUtils.statementDML(sql);
		if (resultado < 0) {
    		todoOk = false;
    		error += "languages ";
    	}
		
		
		if (todoOk)
			System.out.println("Tablas vaciadas correctamente");
		else
			System.out.println("Error al vaciar tablas: " + error);
		
		JdbcUtils.desconexion();
    }
    
    
    /**
     * extraer los chistes almacenados en los ficheros
     */
    private static void extraerChistesDeFichero() {
    	List<Joke> listaChistesAux = new ArrayList<>();
    	listaChistesAux = JsonUtils.leerFicheroConGson("ficherosJson/jokes-es.json",
    			Joke[].class);
    	listaChistesAux.forEach(c -> c.setLang("es"));
    	listaChistes.addAll(listaChistesAux);
    	
    	listaChistesAux = JsonUtils.leerFicheroConGson("ficherosJson/jokes-cs.json",
    			Joke[].class);
    	listaChistesAux.forEach(c -> c.setLang("cs"));
    	listaChistes.addAll(listaChistesAux);
    	
    	listaChistesAux = JsonUtils.leerFicheroConGson("ficherosJson/jokes-de.json",
    			Joke[].class);
    	listaChistesAux.forEach(c -> c.setLang("de"));
    	listaChistes.addAll(listaChistesAux);
    	
    	listaChistesAux = JsonUtils.leerFicheroConGson("ficherosJson/jokes-en.json",
    			Joke[].class);
    	listaChistesAux.forEach(c -> c.setLang("en"));
    	listaChistes.addAll(listaChistesAux);
    	
    	listaChistesAux = JsonUtils.leerFicheroConGson("ficherosJson/jokes-fr.json",
    			Joke[].class);
    	listaChistesAux.forEach(c -> c.setLang("fr"));
    	listaChistes.addAll(listaChistesAux);
    	
    	listaChistesAux = JsonUtils.leerFicheroConGson("ficherosJson/jokes-pt.json",
    			Joke[].class);
    	listaChistesAux.forEach(c -> c.setLang("pt"));
    	listaChistes.addAll(listaChistesAux);
    }
    
    /**
     * extraer la informacion general de JokeApi
     */
    private static void extraerInformacionGeneralJokeApi() {
    	System.out.println("Extrayendo los datos generales de JokeApi...");
    	datosGeneralesJoke = JsonUtils.procesarJokeApiGeneralJson();
    	System.out.println("Datos extraidos correctamente");
    }
    
    
    /**
     * extrae todos los chistes de la api por idioma
     * es:español - cs:checho - de:aleman - en:ingles - fr:frances - pt:portugues
     */
    private static void extraerChistesJokeApi() {       	   	
    	totalChistes = datosGeneralesJoke.getJokes().getTotalCount();
    	System.out.println("Total chistes a descargar: " + totalChistes); 
    	System.out.println("Extrayendo chistes de jokeApi...");       	
    	
    	int totalChistesCs = datosGeneralesJoke.getTotalCs();
    	int totalChistesEs = datosGeneralesJoke.getTotalEs();
    	int totalChistesDe = datosGeneralesJoke.getTotalDe();
    	int totalChistesEn = datosGeneralesJoke.getTotalEn();
    	int totalChistesFr = datosGeneralesJoke.getTotalFr();
    	int totalChistesPt = datosGeneralesJoke.getTotalPt();
    	
    	
    	extraerChistesPorIdioma("es", totalChistesEs);       	
    	extraerChistesPorIdioma("cs", totalChistesCs);
    	extraerChistesPorIdioma("de", totalChistesDe);
    	extraerChistesPorIdioma("pt", totalChistesPt);
    	extraerChistesPorIdioma("en", totalChistesEn);
    	extraerChistesPorIdioma("fr", totalChistesFr);
    	/*
    	extraerChistesPorIdioma("es", 6);       	
    	extraerChistesPorIdioma("cs", 3);
    	extraerChistesPorIdioma("de", 35);
    	extraerChistesPorIdioma("pt", 1);
    	extraerChistesPorIdioma("en", 319);
    	extraerChistesPorIdioma("fr", 999);
    	*/
    }
    
    /**
     * extrae todos los chistes asociados a un idioma 
     * haciendo una pausa de 60 segundos cada 110 descargas
     * el ratio ha bajado a unas 114 descargas por minuto
     * @param idioma
     * @param cantidadChistes
     */
    private static void extraerChistesPorIdioma(String idioma, int cantidadChistes) {
    	for (int i = 0; i <= cantidadChistes; i++) {
    		if (contadorChistesDescargados > 0 && (contadorChistesDescargados % 110 == 0)) {
    			try {    		
    				System.out.println("Pausa de 60 segundos...");
    				Thread.sleep(60000);
    				int chistesPendientes = totalChistes - contadorChistesDescargados;
    				System.out.println("Quedan: " + chistesPendientes + " por descargar. ");      				
    			} catch (InterruptedException e) {
    				System.err.println("Espera interrumpida de forma inesperada");
    			}
    		}
    		
    		Joke chiste = JsonUtils.procesarAPIJson(idioma, i);
        	if (chiste != null) {
        		listaChistes.add(chiste);
        		contadorChistesDescargados++;
        	}
    	}    	    	
    }
    
    /**
     * 
     * @param dato
     * @param sc
     * @return
     */
    private static String pedirDato(String dato, Scanner sc) {
    	System.out.print("Introduce " + dato + ": ");
    	return sc.nextLine();
    }
    
    /**
     * pide un dato obligando a poner un texto no vacio
     * @param dato
     * @param sc
     * @return
     */
    private static String pedirDatoNoVacio(String dato, Scanner sc) {
    	String texto;
    	do {
    		texto = pedirDato(dato, sc);    		
    	}while (texto.isEmpty());
    	return texto;
    }
 
}
