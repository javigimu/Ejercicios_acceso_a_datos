package com.javier.ejercicio_tema2.utilidades;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Arrays;
import java.util.List;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

import com.google.gson.Gson;
import com.javier.ejercicio_tema2.entidades.Joke;
import com.javier.ejercicio_tema2.entidades.MainJoke;

/**
 * metodos para operar con ficheros Json
 * @author Javier Gimenez Muñoz
 *
 */
public class JsonUtils {
	
	/**
	 * Parsea el fichero coches.json indicado en cadenaCompleta para obtener
	 * los campos que realmente interesan y devuelve un jsonString
	 * @param cadenaCompleta
	 * @return
	 */
	public static String parsearFicheroJson(String cadenaCompleta) {
		try {
			// parseado el fichero "coches.json"
			Object obj = new JSONParser().parse(new FileReader(cadenaCompleta));

			// casteando obj a JSONObject
			JSONObject jo = (JSONObject) obj;			
			JSONArray jokes = (JSONArray) jo.get("jokes");
			
			return jokes.toString();
			
		}catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}catch (org.json.simple.parser.ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return "";
	}
	
	/**
	 * Con este método se obtiene una lista de tipo genérico con la extracción
	 * de datos del fichero json con formato correcto en cadenaCompleta	
	 * @param <T>
	 * @param cadenaCompleta
	 * @param clase
	 * @return
	 */
	public static <T> List<T> leerFicheroConGson(String cadenaCompleta,
			Class<T[]> clase) {
        return Arrays.asList(new Gson().fromJson(
        		parsearFicheroJson(cadenaCompleta),clase));
	}	

	/**
	 * extraer datos Json de jokeAPI a partir de un idioma y un id de chiste
	 * @param latitud
	 * @param longitud
	 * @return
	 */
	public static Joke procesarAPIJson(String idioma, int idChiste) {
		
		String url = "https://v2.jokeapi.dev/joke/Any?lang=" + idioma + 
				"&idRange="	+ idChiste;

		return devolverObjetoGsonGenerico(url, Joke.class);
	}		
	
	/**
	 * extraer datos generales Json de jokeAPI
	 * @return
	 */
	public static MainJoke procesarJokeApiGeneralJson() {
		String url = "https://v2.jokeapi.dev/info";

		return devolverObjetoGsonGenerico(url, MainJoke.class);
	}
	
	/**
	 * Metódo genérico que dada una url con un json donde se encuentra un objeto
	 * devuelve un objeto de la clase asociada.
	 * Ejemplo de llamada: JsonUtils.devolverObjetoGsonGenerico
	 * @param <T> Nombre de la clase
	 * @param url
	 * @param clase Array de elementos del tipo de la clase
	 * @return
	 */
	public static <T> T devolverObjetoGsonGenerico(String url, Class<T> clase) {
        return new Gson().fromJson(InternetUtils.readUrl(url),clase);
	}
	
}
